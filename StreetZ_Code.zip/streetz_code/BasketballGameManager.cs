using Unity.Netcode;
using Unity.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Server-authoritative game manager. Owns the canonical match state (scores,
/// possession, phase, shot clock) and validates every client-originated change.
/// </summary>
public class BasketballGameManager : NetworkBehaviour
{
    public static BasketballGameManager Instance;

    // Replicated state. NetworkVariables auto-sync from server → all clients

    public enum GameState : byte
    {
        WaitingToStart,
        TipOff,
        CheckUp,
        Playing,
        GameOver
    }

    /// <summary>Current phase of the match - read by every client to drive UI.</summary>
    public NetworkVariable<GameState> CurrentState = new NetworkVariable<GameState>(
        GameState.WaitingToStart,
        readPerm:  NetworkVariableReadPermission.Everyone,
        writePerm: NetworkVariableWritePermission.Server);

    /// <summary>
    /// Convenience flag for AI and other gameplay code that wants to know
    /// if the ball is live. Reads the replicated state variable.
    /// </summary>
    public bool BallInPlay => CurrentState.Value == GameState.Playing;

    /// <summary>Score for client 0 (host / Player 1).</summary>
    public NetworkVariable<int> HostScore = new NetworkVariable<int>(
        0, readPerm: NetworkVariableReadPermission.Everyone,
           writePerm: NetworkVariableWritePermission.Server);

    /// <summary>Score for client 1 (Player 2).</summary>
    public NetworkVariable<int> ClientScore = new NetworkVariable<int>(
        0, readPerm: NetworkVariableReadPermission.Everyone,
           writePerm: NetworkVariableWritePermission.Server);

    /// <summary>
    /// ClientId of whichever player currently has possession.
    /// ulong.MaxValue = nobody (loose ball).
    /// </summary>
    public NetworkVariable<ulong> PossessingClientId = new NetworkVariable<ulong>(
        ulong.MaxValue,
        readPerm:  NetworkVariableReadPermission.Everyone,
        writePerm: NetworkVariableWritePermission.Server);

    /// <summary>Shot clock seconds remaining, server-authoritative.</summary>
    public NetworkVariable<float> ShotClock = new NetworkVariable<float>(
        24f, readPerm: NetworkVariableReadPermission.Everyone,
             writePerm: NetworkVariableWritePermission.Server);

    // Local state (set in Inspector on the host - or auto-discovered)

    [Header("Game Rules")]
    public int   PointsToWin       = 10;
    public float ShotClockDuration = 24f;
    public bool  MakeItTakeIt      = false;

    [Header("Court - Half Court")]
    public Transform Hoop;
    public Transform CheckUpPoint;
    public Transform HostSpawn;
    public Transform ClientSpawn;

    [Header("Ball")]
    public GameObject Basketball;
    public Transform  BallSpawnPoint;
    private Rigidbody _ballRb;

    [Header("UI (each client's own display)")]
    public TextMeshProUGUI ScoreText;
    public TextMeshProUGUI ShotClockText;
    public TextMeshProUGUI PossessionText;
    public TextMeshProUGUI AnnouncerText;
    public TextMeshProUGUI CheckUpText;
    public GameObject      GameOverPanel;
    public TextMeshProUGUI GameOverText;
    public Button          StartButton;

    // Convenience cache - host maintains a dict of clientId → player GameObject
    private readonly Dictionary<ulong, GameObject> _playersByClient = new();

    // Unity Lifecycle

    void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }
    }

    public override void OnNetworkSpawn()
    {
        // Subscribe UI updaters on every client (host included).
        // The NetworkVariable change callbacks fire locally whenever the value
        // is mutated server-side and the change reaches this client.
        CurrentState.OnValueChanged        += OnStateChanged;
        HostScore.OnValueChanged           += (_, __) => RefreshScoreUI();
        ClientScore.OnValueChanged         += (_, __) => RefreshScoreUI();
        PossessingClientId.OnValueChanged  += (_, __) => RefreshPossessionUI();

        if (GameOverPanel != null) GameOverPanel.SetActive(false);
        if (CheckUpText   != null) CheckUpText.text = "";
        if (Basketball    != null) _ballRb = Basketball.GetComponent<Rigidbody>();

        RefreshScoreUI();
        RefreshPossessionUI();

        if (IsServer)
        {
            // Server gathers references to players that NetworkSpawnManager spawned.
            // NetworkSpawnManager runs just before this, so the clients dictionary
            // already has entries.
            RegisterExistingPlayers();

            // Hook late-joiners so we can include them in the dict if they arrive
            NetworkManager.OnClientConnectedCallback += OnClientConnectedServer;
        }

        // Only the host shows the Start button; clients just see "waiting".
        if (StartButton != null)
        {
            StartButton.gameObject.SetActive(IsServer);
            StartButton.onClick.AddListener(OnStartButtonClicked);
        }

        if (AnnouncerText != null)
            AnnouncerText.text = IsServer ? "Press START" : "Waiting for host...";
    }

    public override void OnNetworkDespawn()
    {
        CurrentState.OnValueChanged        -= OnStateChanged;
        HostScore.OnValueChanged           -= (_, __) => RefreshScoreUI();
        ClientScore.OnValueChanged         -= (_, __) => RefreshScoreUI();
        PossessingClientId.OnValueChanged  -= (_, __) => RefreshPossessionUI();

        if (IsServer && NetworkManager != null)
            NetworkManager.OnClientConnectedCallback -= OnClientConnectedServer;
    }

    void Update()
    {
        // Shot-clock ticking runs only on the server - the NetworkVariable
        // replicates to clients automatically. A client never decrements
        // the clock itself, which prevents clients from "cheating time".
        if (!IsServer) { UpdateShotClockText(); return; }

        if (CurrentState.Value == GameState.Playing)
        {
            ShotClock.Value -= Time.deltaTime;
            if (ShotClock.Value <= 0f) HandleShotClockViolation();
        }

        UpdateShotClockText();
    }

    // Server: Player Registry

    private void RegisterExistingPlayers()
    {
        foreach (var pair in NetworkManager.ConnectedClients)
        {
            var po = pair.Value.PlayerObject;
            if (po != null) _playersByClient[pair.Key] = po.gameObject;
        }
    }

    private void OnClientConnectedServer(ulong clientId)
    {
        // Called on the server when any client (including the host) connects.
        // We wait one frame because the player object may not have spawned yet.
        StartCoroutine(RegisterAfterFrame(clientId));
    }

    private IEnumerator RegisterAfterFrame(ulong clientId)
    {
        yield return null;
        if (NetworkManager.ConnectedClients.TryGetValue(clientId, out var c)
            && c.PlayerObject != null)
            _playersByClient[clientId] = c.PlayerObject.gameObject;
    }

    // Client → server RPCs
    // Clients call these to request changes; server is free to reject.

    /// <summary>
    /// Any client can request the match to begin. Only the server will
    /// actually act on it, and only from WaitingToStart.
    /// </summary>
    [Rpc(SendTo.Server, RequireOwnership = false)]
    public void BeginGameServerRpc(RpcParams rpcParams = default)
    {
        // Reject if we aren't in the correct phase (defence in depth -
        // the client UI should also prevent this, but we don't trust it).
        if (CurrentState.Value != GameState.WaitingToStart) return;

        // Optional: only allow the host to start. Comment out for any-player-starts.
        if (rpcParams.Receive.SenderClientId != NetworkManager.ServerClientId) return;

        StartCoroutine(TipOffSequence());
    }

    /// <summary>
    /// Client reports their ball went through the hoop.
    /// A fully cheat-proof version would run the shot's physics on the server
    /// too; this is a pragmatic middle ground documented as a limitation
    /// </summary>
    [Rpc(SendTo.Server, RequireOwnership = false)]
    public void ReportScoreServerRpc(int requestedPoints, Vector3 shooterPosition,
                                     RpcParams rpcParams = default)
    {
        if (CurrentState.Value != GameState.Playing) return;

        // Validation- server refuses to award points unless:
        //   1. The sender currently has possession (per server state)
        //   2. The requested points (2 or 3) matches the shooter's distance
        //   3. The shooter isn't implausibly far from the hoop (anti-teleport)
        ulong sender = rpcParams.Receive.SenderClientId;
        if (PossessingClientId.Value != sender)
        {
            Debug.LogWarning($"[Server] Rejected score from client {sender}: not in possession");
            return;
        }

        float dist = Hoop != null
            ? Vector2.Distance(
                new Vector2(shooterPosition.x, shooterPosition.z),
                new Vector2(Hoop.position.x,   Hoop.position.z))
            : 0f;

        int validPoints = dist > 7.25f ? 3 : 2;
        if (requestedPoints != validPoints)
        {
            Debug.LogWarning($"[Server] Client requested {requestedPoints}pts but distance {dist:F1}m = {validPoints}pts. Using server value.");
            requestedPoints = validPoints;
        }

        if (dist > 40f)
        {
            Debug.LogWarning($"[Server] Rejected impossible shot from {dist:F1}m");
            return;
        }

        ApplyScore(requestedPoints, sender);
    }

    /// <summary>
    /// Server-side entry point for awarding a score - called directly by
    /// the server's HoopSensor (which is already the trusted source).
    /// Skips the RPC hop since we're already on the server.
    /// </summary>
    public void AwardScoreServerSide(int points, Vector3 shooterPosition, ulong shooterClientId)
    {
        if (!IsServer) return;
        if (CurrentState.Value != GameState.Playing) return;

        // Re-use the validation logic from the RPC path by just applying
        // the score directly - HoopSensor is already trusted because only
        // the server runs it.
        ApplyScore(points, shooterClientId);
    }

    /// <summary>
    /// Client reports they turned over the ball (bad steal, out of bounds, etc.)
    /// Server decides who gets possession next.
    /// </summary>
    [Rpc(SendTo.Server, RequireOwnership = false)]
    public void ReportTurnoverServerRpc(RpcParams rpcParams = default)
    {
        if (CurrentState.Value != GameState.Playing) return;

        ulong sender = rpcParams.Receive.SenderClientId;
        if (PossessingClientId.Value != sender) return;

        // Possession flips to the other client.
        ulong other = OtherClient(sender);
        AnnounceClientRpc(new FixedString32Bytes("TURNOVER"));
        StartCoroutine(CheckUpSequence(other));
    }

    // Server-side game flow (runs only on host)

    private void ApplyScore(int points, ulong scorerId)
    {
        if (scorerId == NetworkManager.ServerClientId)
            HostScore.Value += points;
        else
            ClientScore.Value += points;

        string ptStr = points == 3 ? "THREE!" : "BUCKET";
        AnnounceClientRpc(new FixedString32Bytes($"+{points} - {ptStr}"));

        if (HostScore.Value >= PointsToWin || ClientScore.Value >= PointsToWin)
        {
            StartCoroutine(EndGameSequence());
            return;
        }

        // Make it Take it: scorer keeps ball. Standard: scored-on team gets ball.
        ulong nextPossession = MakeItTakeIt ? scorerId : OtherClient(scorerId);
        StartCoroutine(ResetAfterScore(nextPossession));
    }

    private IEnumerator TipOffSequence()
    {
        CurrentState.Value = GameState.TipOff;
        AnnounceClientRpc(new FixedString32Bytes("TIP OFF"));
        PositionAtCheckUp();
        ResetBallToSpawn();
        yield return new WaitForSeconds(1.5f);

        // Random first possession - server rolls, broadcasts via NetworkVariable.
        ulong first = Random.value > 0.5f
            ? NetworkManager.ServerClientId
            : FirstNonHostClient();

        AnnounceClientRpc(new FixedString32Bytes(
            first == NetworkManager.ServerClientId ? "HOST ball" : "CLIENT ball"));
        yield return new WaitForSeconds(1.5f);

        StartCoroutine(CheckUpSequence(first));
    }

    private IEnumerator CheckUpSequence(ulong offensiveClient)
    {
        CurrentState.Value      = GameState.CheckUp;
        PossessingClientId.Value = offensiveClient;

        ResetBallToSpawn();
        PositionAtCheckUp();
        AnnounceClientRpc(new FixedString32Bytes("CHECK BALL"));

        // Apply possession physically - server tells the correct player's
        // BallHandler to pick up the ball.
        GivePossessionToPlayer(offensiveClient);

        yield return new WaitForSeconds(2f);

        ShotClock.Value    = ShotClockDuration;
        CurrentState.Value = GameState.Playing;
    }

    private IEnumerator ResetAfterScore(ulong nextClient)
    {
        CurrentState.Value = GameState.CheckUp;
        yield return new WaitForSeconds(2f);
        StartCoroutine(CheckUpSequence(nextClient));
    }

    private void HandleShotClockViolation()
    {
        ulong current = PossessingClientId.Value;
        AnnounceClientRpc(new FixedString32Bytes("SHOT CLOCK!"));
        StartCoroutine(CheckUpSequence(OtherClient(current)));
    }

    private IEnumerator EndGameSequence()
    {
        CurrentState.Value = GameState.GameOver;

        bool hostWon = HostScore.Value >= PointsToWin;
        AnnounceClientRpc(new FixedString32Bytes(hostWon ? "HOST WINS" : "CLIENT WINS"));

        ReleaseBallFromAll();
        if (_ballRb != null)
        {
            _ballRb.linearVelocity  = Vector3.zero;
            _ballRb.angularVelocity = Vector3.zero;
            _ballRb.isKinematic     = true;
        }

        yield return new WaitForSeconds(1.5f);

        ShowGameOverPanelClientRpc(HostScore.Value, ClientScore.Value);
    }

    // Server → client RPCs (one-shot UI events that don't need persistence)

    [ClientRpc]
    private void AnnounceClientRpc(FixedString32Bytes msg)
    {
        if (AnnouncerText == null) return;
        AnnouncerText.text = msg.ToString();
        CancelInvoke(nameof(ClearAnnouncer));
        Invoke(nameof(ClearAnnouncer), 1.8f);
    }

    [ClientRpc]
    private void ShowGameOverPanelClientRpc(int hostFinal, int clientFinal)
    {
        if (GameOverPanel != null) GameOverPanel.SetActive(true);
        if (GameOverText  != null)
            GameOverText.text =
                $"FINAL\nHost  {hostFinal}  -  {clientFinal}  Client";
    }

    private void ClearAnnouncer()
    {
        if (AnnouncerText != null) AnnouncerText.text = "";
    }

    // Client-side UI refresh (fires from NetworkVariable.OnValueChanged)

    private void OnStateChanged(GameState oldVal, GameState newVal)
    {
        if (CheckUpText != null)
            CheckUpText.text = newVal == GameState.CheckUp ? "CHECK BALL" : "";
    }

    private void RefreshScoreUI()
    {
        if (ScoreText == null) return;
        ScoreText.text = $"HOST  {HostScore.Value}  -  {ClientScore.Value}  CLIENT";
    }

    private void RefreshPossessionUI()
    {
        if (PossessionText == null) return;
        if (PossessingClientId.Value == ulong.MaxValue)
            PossessionText.text = "LOOSE BALL";
        else if (PossessingClientId.Value == NetworkManager.LocalClientId)
            PossessionText.text = "▶ YOU";
        else
            PossessionText.text = "OPPONENT ◀";
    }

    private void UpdateShotClockText()
    {
        if (ShotClockText == null) return;
        ShotClockText.text = CurrentState.Value == GameState.Playing
            ? Mathf.Ceil(ShotClock.Value).ToString()
            : "--";
    }

    // Button Hooks

    private void OnStartButtonClicked()
    {
        // Any client pressing the button sends a ServerRpc; server decides.
        BeginGameServerRpc();
    }

    // Server Helpers- physical state mutation

    private void PositionAtCheckUp()
    {
        if (!IsServer) return;

        foreach (var pair in _playersByClient)
        {
            Transform spawn = pair.Key == NetworkManager.ServerClientId
                ? HostSpawn : ClientSpawn;
            if (spawn != null) MoveCharacter(pair.Value, spawn.position);
        }
    }

    private void ResetBallToSpawn()
    {
        if (!IsServer || _ballRb == null || Basketball == null) return;
        _ballRb.isKinematic     = true;
        _ballRb.linearVelocity  = Vector3.zero;
        _ballRb.angularVelocity = Vector3.zero;
        Basketball.transform.position = BallSpawnPoint != null
            ? BallSpawnPoint.position
            : (CheckUpPoint != null ? CheckUpPoint.position + Vector3.up : Vector3.up);
        _ballRb.isKinematic = false;
    }

    private void GivePossessionToPlayer(ulong clientId)
    {
        if (!IsServer) return;
        ReleaseBallFromAll();

        if (_playersByClient.TryGetValue(clientId, out GameObject p))
        {
            PlayerBallHandler bh = p.GetComponent<PlayerBallHandler>();
            if (bh != null) bh.GainPossession();
        }
    }

    private void ReleaseBallFromAll()
    {
        foreach (var p in _playersByClient.Values)
        {
            if (p == null) continue;
            PlayerBallHandler bh = p.GetComponent<PlayerBallHandler>();
            if (bh != null) bh.ReleaseBallForShot();
        }
    }

    private void MoveCharacter(GameObject obj, Vector3 pos)
    {
        if (obj == null) return;
        CharacterController cc = obj.GetComponent<CharacterController>();
        if (cc != null) { cc.enabled = false; obj.transform.position = pos; cc.enabled = true; }
        else obj.transform.position = pos;
    }

    private ulong FirstNonHostClient()
    {
        foreach (ulong id in NetworkManager.ConnectedClientsIds)
            if (id != NetworkManager.ServerClientId) return id;
        return NetworkManager.ServerClientId; // fallback (playing solo)
    }

    private ulong OtherClient(ulong id)
    {
        foreach (ulong other in NetworkManager.ConnectedClientsIds)
            if (other != id) return other;
        return id; // solo - no other client
    }
}
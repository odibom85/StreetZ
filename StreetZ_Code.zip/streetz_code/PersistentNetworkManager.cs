using Unity.Netcode;
using UnityEngine;

public class PersistentNetworkManager : MonoBehaviour
{
    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
}
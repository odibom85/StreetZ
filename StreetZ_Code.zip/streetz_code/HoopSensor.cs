using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Detects when the ball passes down through the hoop. Only the server actually
/// reports a score; clients see the trigger fire but don't mutate state.
/// </summary>
public class HoopSensor : MonoBehaviour
{
    public Transform HoopCenter;
    public float ThreePointLine = 7.25f;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Ball")) return;

        // Must be falling down through the hoop - prevents scoring on the
        // ball being thrown up through it from below.
        Rigidbody rb = other.GetComponent<Rigidbody>();
        if (rb == null || rb.linearVelocity.y > 0) return;

        BallState state = other.GetComponent<BallState>();
        if (state == null) return;

        // Only the server is authoritative for scoring.
        // Clients ignore local trigger detection to prevent double-scoring.
        if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsServer)
            return;

        // Work out 2 vs 3 points from the shot origin recorded when the shot launched.
        float dist = Vector2.Distance(
            new Vector2(state.ShotOrigin.x, state.ShotOrigin.z),
            new Vector2(HoopCenter.position.x, HoopCenter.position.z));
        int points = dist > ThreePointLine ? 3 : 2;

        // Work out which client shot. LastShooter is the GameObject that released the ball.
        if (state.LastShooter == null) return;
        NetworkObject shooterNetObj = state.LastShooter.GetComponent<NetworkObject>();
        if (shooterNetObj == null) return;
        ulong shooterClient = shooterNetObj.OwnerClientId;

        // Tell the GameManager - it handles validation and NetworkVariable updates.
        if (BasketballGameManager.Instance != null)
        {
            // We can call the validation RPC directly on the server since
            // we are the server. It will still do its sanity checks.
            BasketballGameManager.Instance.AwardScoreServerSide(
                points, state.ShotOrigin, shooterClient);
        }

        Debug.Log($"[HoopSensor] Server scored {points} pts for client {shooterClient}");
    }
}
using Unity.Netcode;
using UnityEngine;

public class NetworkPlayerSetup : NetworkBehaviour
{
    public override void OnNetworkSpawn()
    {
        var ctrl = GetComponent<PlayerController>();
        
        // If we are testing locally, assign PlayerIndex based on ClientId
        if (ctrl != null && ctrl.IsLocalTesting)
        {
            ctrl.PlayerIndex = (int)OwnerClientId;
            gameObject.tag = "Player";
            // Ensure components stay enabled for local control
            ctrl.enabled = true;
            return; 
        }

        // Standard Networking Logic
        if (IsOwner)
        {
            gameObject.tag = "Player";
        }
        else
        {
            gameObject.tag = "AI";
            if (ctrl != null) ctrl.enabled = false;
            // Disable other scripts...
        }
    }
}
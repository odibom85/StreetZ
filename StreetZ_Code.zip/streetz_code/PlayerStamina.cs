using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class PlayerStamina : MonoBehaviour
{
    [Header("Stats")]
    public float StaminaPercent = 1.0f;
    
    [Header("References (Wired by SpawnManager)")]
    public PlayerController    Controller;
    public PlayerBallHandler   BallHandler;
    public PlayerDefense       DefenseScript;
    public PlayerShooting      ShootingScript;
    public CharacterController CC;

    [Header("Drain Settings")]
    public float SprintDrainRate      = 0.1f;
    public float DefenseStanceRate    = 0.15f;
    public float CrossoverDrainCost   = 0.05f;
    public float BehindBackDrainCost  = 0.07f;
    public float DriveDrainCost       = 0.1f;

    public bool IsInDefStance { get; private set; }
    public bool IsSprinting   { get; private set; }

    void Update()
    {
        int pIdx = (Controller != null) ? Controller.PlayerIndex : 0;
        Gamepad gp = (Gamepad.all.Count > pIdx) ? Gamepad.all[pIdx] : null;

        if (gp != null)
        {
            IsSprinting = gp.leftTrigger.isPressed;
            IsInDefStance = gp.leftShoulder.isPressed;
        }

        if (IsInDefStance)
            StaminaPercent = Mathf.Clamp01(StaminaPercent - DefenseStanceRate * Time.deltaTime);
        else if (IsSprinting)
            StaminaPercent = Mathf.Clamp01(StaminaPercent - SprintDrainRate * Time.deltaTime);
        else
            StaminaPercent = Mathf.Clamp01(StaminaPercent + 0.12f * Time.deltaTime);
    }

    public void DrainCrossover()  => StaminaPercent = Mathf.Clamp01(StaminaPercent - CrossoverDrainCost);
    public void DrainBehindBack() => StaminaPercent = Mathf.Clamp01(StaminaPercent - BehindBackDrainCost);
    public void DrainSprint()     => StaminaPercent = Mathf.Clamp01(StaminaPercent - (SprintDrainRate * Time.deltaTime));
    public void DrainDrive()      => StaminaPercent = Mathf.Clamp01(StaminaPercent - DriveDrainCost);
}
using UnityEngine;
using UnityEngine.InputSystem;
using Unity.Netcode;

/// <summary>
/// Lets the player pick up a loose ball with the East button (B/Circle/E).
/// </summary>
public class BallPickup : MonoBehaviour
{
    public PlayerBallHandler BallHandler;
    public PlayerShooting ShootingScript;
    public float PickupRadius = 2.5f;
    public LayerMask BallLayer;

    private NetworkObject _netObj;

    void Awake()
    {
        _netObj = GetComponent<NetworkObject>();
    }

    void Update()
    {
        // Only process input for local player
        if (_netObj != null && !_netObj.IsOwner) return;
        if (BallHandler == null || BallHandler.HasBall) return;

        Gamepad  gp = Gamepad.current;
        Keyboard kb = Keyboard.current;

        bool pickupPressed = (gp != null && gp.buttonEast.wasPressedThisFrame)
                          || (kb != null && kb.eKey.wasPressedThisFrame);

        if (pickupPressed)
            TryPickup();
    }

    private void TryPickup()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, PickupRadius, BallLayer);

        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.CompareTag("Ball"))
            {
                BallHandler.GainPossession();

                if (ShootingScript != null)
                    ShootingScript.ResetShootingState();

                break;
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, PickupRadius);
    }
}
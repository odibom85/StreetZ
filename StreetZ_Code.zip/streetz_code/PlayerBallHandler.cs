using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;
using System.Collections;
using Unity.Netcode;

/// <summary>
/// Manual dribble system. Right stick controls ball position and the player can
/// flick to crossover, behind-the-back, or hesitate. Vulnerable windows during moves
/// let the defender attempt a steal.
/// </summary>
public class PlayerBallHandler : MonoBehaviour
{
    // References
    [Header("Hand Slots")]
    public Transform LeftHandSlot;
    public Transform RightHandSlot;
    private Transform _activeSlot;

    [Header("Ball")]
    public GameObject Ball;
    private Rigidbody _ballRb;
    public PlayerShooting Shooting;
    public PlayerStamina  Stamina;

    // Manual Dribble Settings
    [Header("Manual Dribble - Right Stick")]
    public float MaxSideOffset    = 0.7f;
    public float MaxForwardOffset = 0.6f;
    public float BallMaxHeight    = 0.85f;
    public float BallFloorHeight  = 0.12f;
    public float BallFollowSpeed  = 12f;
    public float BaseBounceSpeed  = 4f;
    [Range(0f, 0.5f)]
    public float StickDeadzone    = 0.15f;
    public float FollowSmooth     = 0.06f;
    public LayerMask FloorLayer;

    // Crossover Settings
    [Header("Crossover - RT + Right Stick")]
    public float CrossoverFlickThreshold = 0.65f;
    public float CrossoverFlickSpeed     = 8f;
    public float CrossoverDuration       = 0.28f;
    public float VulnerableWindow        = 0.55f;
    public float VulnerableStealMult     = 3.5f;

    // Other Move Settings
    [Header("Other Moves")]
    public float BehindBackDuration  = 0.32f;
    public float HesitationDuration  = 0.38f;

    // Combo Boost
    [Header("Crossover Combo")]
    public float SmallBoostMultiplier = 1.3f;
    public float BigBoostMultiplier   = 1.7f;
    public float BoostDuration        = 2.8f;
    public float ComboChainWindow     = 2.0f;
    [Range(0f, 1f)]
    public float AnkleBreakerSlowMo   = 0.4f;
    public float AnkleBreakerSlowDuration = 0.6f;

    // Grounded Movement Cap
    [Header("Grounded Dribble")]
    public float DribbleSpeedScale    = 0.72f;
    public float SprintActivationDelay = 0.12f;

    // UI
    [Header("UI")]
    public TextMeshProUGUI DribbleFeedbackText;
    public TextMeshProUGUI ComboText;
    public UnityEngine.UI.Image CrossoverReadyIndicator;

    // Public State
    [Header("State - Read Only")]
    public bool  HasBall        = true;
    public bool  IsRightHanded  = true;
    public bool  IsDoingMove    = false;
    public bool  IsVulnerable   = false;
    public float VulnerableStealMultiplier => IsVulnerable ? VulnerableStealMult : 1f;

    // Private
    private float   _bounceCycle;
    private Vector3 _ballVelocity;
    private Vector3 _smoothBallPos;
    private bool    _isSprinting;
    private float   _staminaPercent = 1f;
    private NetworkObject _netObj;

    // Right stick
    private Vector2 _rightStick;
    private Vector2 _prevRightStick;
    private float   _stickVelocityX;

    // RT / sprint / crossover intent
    private bool  _rtHeld          = false;
    private float _rtHeldTime      = 0f;
    private bool  _sprintActive    = false;
    private bool  _crossoverArmed  = false;

    // Combo
    private int     _crossoverStreak   = 0;
    private float   _lastCrossoverTime = -999f;
    private float   _boostMultiplier   = 1f;
    private Coroutine _boostRoutine;
    private Coroutine _moveRoutine;
    private Coroutine _feedbackRoutine;
    private Coroutine _vulnerableRoutine;

    // Unity
    void Start()
    {
        _netObj        = GetComponent<NetworkObject>();
        if (Ball == null) return;
        _ballRb        = Ball.GetComponent<Rigidbody>();
        _activeSlot    = RightHandSlot;
        _smoothBallPos = Ball.transform.position;
        if (Shooting == null) Shooting = GetComponent<PlayerShooting>();
        if (Stamina  == null) Stamina  = GetComponent<PlayerStamina>();
        if (HasBall) GainPossession();
        else ReleaseBallForShot();
    }

    void Update()
    {
        if (_netObj != null && !_netObj.IsOwner) return;

        ReadInputs();

        if (!HasBall || IsDoingMove) return;

        DriveManualDribble();
        DetectCrossover();
        DetectOtherMoves();
        PollHesitation();
        UpdateCrossoverReadyUI();
    }

    // Input Reading
    private void ReadInputs()
    {
        if (!gameObject.CompareTag("Player")) return;

        Gamepad gp = Gamepad.current;
        _prevRightStick = _rightStick;

        if (gp != null)
        {
            Vector2 raw = gp.rightStick.ReadValue();
            _rightStick = raw.magnitude > StickDeadzone ? raw : Vector2.zero;

            bool rtNow = gp.rightTrigger.isPressed;

            if (rtNow)
            {
                _rtHeldTime += Time.deltaTime;
                _rtHeld      = true;
            }
            else
            {
                _rtHeld      = false;
                _rtHeldTime  = 0f;
                _sprintActive = false;
            }
        }
        else
        {
            _rightStick   = Vector2.zero;
            _rtHeld       = false;
            _rtHeldTime   = 0f;
            _sprintActive = false;
        }

        _stickVelocityX = (_rightStick.x - _prevRightStick.x) / Mathf.Max(Time.deltaTime, 0.001f);

        _sprintActive = _rtHeld && _rtHeldTime >= SprintActivationDelay && !IsDoingMove;
        _crossoverArmed = _rtHeld && !_sprintActive;

        SetSprinting(_sprintActive);
    }

    // Crossover Detection
    private void DetectCrossover()
    {
        if (!gameObject.CompareTag("Player") || Gamepad.current == null) return;
        if (!_rtHeld) return;

        bool flickRight = _prevRightStick.x < CrossoverFlickThreshold * -0.5f
                       && _rightStick.x     >  CrossoverFlickThreshold;
        bool flickLeft  = _prevRightStick.x >  CrossoverFlickThreshold * 0.5f
                       && _rightStick.x     < -CrossoverFlickThreshold;

        bool fastEnough = Mathf.Abs(_stickVelocityX) >= CrossoverFlickSpeed;

        if ((flickRight || flickLeft) && fastEnough)
        {
            _rtHeldTime   = 0f;
            _sprintActive = false;
            TriggerCrossover(flickRight);
        }
    }

    // Other Move Detection
    private void DetectOtherMoves()
    {
        if (!gameObject.CompareTag("Player") || Gamepad.current == null) return;
        if (_rtHeld) return;

        bool hardDown = _prevRightStick.y > -0.4f && _rightStick.y < -0.85f;
        if (hardDown)
            _moveRoutine = StartCoroutine(BehindBackRoutine());
    }

    /// <summary>
    /// Hesitation move - polled directly from keyboard (H key) or left stick click.
    /// Replaces the old OnHesitation(InputValue) callback.
    /// </summary>
    private void PollHesitation()
    {
        if (!HasBall || IsDoingMove) return;

        Gamepad  gp = Gamepad.current;
        Keyboard kb = Keyboard.current;

        bool hesPressed = (gp != null && gp.leftStickButton.wasPressedThisFrame)
                       || (kb != null && kb.hKey.wasPressedThisFrame);

        if (hesPressed)
            _moveRoutine = StartCoroutine(HesitationRoutine());
    }

    // Manual Dribble Driver
    private void DriveManualDribble()
    {
        Vector3 right   = transform.right;   right.y   = 0f; right.Normalize();
        Vector3 forward = transform.forward; forward.y = 0f; forward.Normalize();

        Vector3 stickOffset = (right   * (_rightStick.x * MaxSideOffset))
                            + (forward * (_rightStick.y * MaxForwardOffset));

        Vector3 handFlat = new Vector3(_activeSlot.position.x, 0f, _activeSlot.position.z);
        Vector3 targetXZ = handFlat + stickOffset;

        if (!_rtHeld)
        {
            if      (_rightStick.x >  0.35f && !IsRightHanded) SwitchHand(true);
            else if (_rightStick.x < -0.35f &&  IsRightHanded) SwitchHand(false);
        }

        float fatigue     = Mathf.Lerp(0.55f, 1f, _staminaPercent);
        float sprintFact  = _sprintActive ? 1.4f : 1f;
        float bounceSpeed = BaseBounceSpeed * fatigue * sprintFact * _boostMultiplier;

        _bounceCycle += Time.deltaTime * bounceSpeed;
        float bounce  = Mathf.Abs(Mathf.Sin(_bounceCycle));

        float floorY = BallFloorHeight;
        if (Physics.Raycast(new Vector3(targetXZ.x, _activeSlot.position.y, targetXZ.z),
                            Vector3.down, out RaycastHit hit, 2f, FloorLayer))
            floorY = hit.point.y + BallFloorHeight;

        float stickMag = _rightStick.magnitude;
        float maxH     = Mathf.Lerp(BallMaxHeight, BallMaxHeight * 0.65f, stickMag);
        float targetY  = Mathf.Lerp(floorY, floorY + maxH, bounce);

        _smoothBallPos = Vector3.SmoothDamp(
            _smoothBallPos,
            new Vector3(targetXZ.x, _smoothBallPos.y, targetXZ.z),
            ref _ballVelocity, FollowSmooth, BallFollowSpeed);

        Ball.transform.position = new Vector3(_smoothBallPos.x, targetY, _smoothBallPos.z);
    }

    // Move Routines
    private void TriggerCrossover(bool toRight)
    {
        if (IsDoingMove) return;
        _moveRoutine = StartCoroutine(CrossoverRoutine(toRight));
    }

    private IEnumerator CrossoverRoutine(bool toRight)
    {
        IsDoingMove  = true;
        IsVulnerable = true;
        ShowFeedback(toRight ? "CROSSOVER →" : "← CROSSOVER");

        Vector3   startPos = Ball.transform.position;
        Transform endSlot  = toRight ? RightHandSlot : LeftHandSlot;

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / CrossoverDuration;
            float easedT = t * t * (3f - 2f * t);
            Vector3 mid  = (startPos + endSlot.position) * 0.5f
                         + Vector3.down * 0.35f
                         + transform.forward * 0.1f;
            Ball.transform.position = Vector3.Lerp(
                Vector3.Lerp(startPos, mid, easedT),
                Vector3.Lerp(mid, endSlot.position, easedT), easedT);
            yield return null;
        }

        SwitchHand(toRight);
        Stamina?.DrainCrossover();
        _smoothBallPos = Ball.transform.position;
        IsDoingMove    = false;

        RegisterCrossoverCombo();

        if (_vulnerableRoutine != null) StopCoroutine(_vulnerableRoutine);
        _vulnerableRoutine = StartCoroutine(VulnerableWindow_Routine());
    }

    private IEnumerator VulnerableWindow_Routine()
    {
        yield return new WaitForSeconds(VulnerableWindow);
        IsVulnerable = false;
    }

    private IEnumerator BehindBackRoutine()
    {
        IsDoingMove  = true;
        IsVulnerable = true;
        ShowFeedback("BEHIND THE BACK!");

        Vector3   startPos = Ball.transform.position;
        Transform endSlot  = IsRightHanded ? LeftHandSlot : RightHandSlot;
        Vector3   behindPt = transform.position
                           - transform.forward * 0.45f
                           + Vector3.up * 0.65f;

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / BehindBackDuration;
            Ball.transform.position = Vector3.Lerp(
                Vector3.Lerp(startPos, behindPt, t),
                Vector3.Lerp(behindPt, endSlot.position, t), t);
            yield return null;
        }

        SwitchHand(!IsRightHanded);
        Stamina?.DrainBehindBack();
        _smoothBallPos = Ball.transform.position;
        IsDoingMove    = false;

        if (_vulnerableRoutine != null) StopCoroutine(_vulnerableRoutine);
        _vulnerableRoutine = StartCoroutine(VulnerableWindow_Routine());
    }

    private IEnumerator HesitationRoutine()
    {
        IsDoingMove = true;
        ShowFeedback("HESITATION!");

        Vector3 startPos  = Ball.transform.position;
        Vector3 jabTarget = startPos + transform.forward * 0.5f + Vector3.down * 0.15f;

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / (HesitationDuration * 0.45f);
            Ball.transform.position = Vector3.Lerp(startPos, jabTarget, t);
            yield return null;
        }
        t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / (HesitationDuration * 0.55f);
            Ball.transform.position = Vector3.Lerp(jabTarget, _activeSlot.position, t);
            yield return null;
        }

        _smoothBallPos = Ball.transform.position;
        IsDoingMove    = false;
    }

    // Combo System
    private void RegisterCrossoverCombo()
    {
        float now = Time.time;
        if (now - _lastCrossoverTime <= ComboChainWindow)
            _crossoverStreak++;
        else
            _crossoverStreak = 1;
        _lastCrossoverTime = now;

        if (ComboText != null) ComboText.text = $"x{_crossoverStreak}";

        if (_crossoverStreak >= 3)
        {
            ApplyBoost(BigBoostMultiplier, "ANKLE BREAKER!");
            StartCoroutine(AnkleBreakerEffect());
            _crossoverStreak = 0;
        }
        else if (_crossoverStreak == 2)
        {
            ApplyBoost(SmallBoostMultiplier, "x2 COMBO");
        }
    }

    private IEnumerator AnkleBreakerEffect()
    {
        Time.timeScale      = AnkleBreakerSlowMo;
        Time.fixedDeltaTime = 0.02f * Time.timeScale;
        yield return new WaitForSecondsRealtime(AnkleBreakerSlowDuration);
        Time.timeScale      = 1f;
        Time.fixedDeltaTime = 0.02f;
    }

    private void ApplyBoost(float mult, string label)
    {
        _boostMultiplier = mult;
        ShowFeedback(label);
        if (_boostRoutine != null) StopCoroutine(_boostRoutine);
        _boostRoutine = StartCoroutine(BoostExpiry());
    }

    private IEnumerator BoostExpiry()
    {
        yield return new WaitForSeconds(BoostDuration);
        _boostMultiplier = 1f;
        if (ComboText != null) ComboText.text = "";
    }

    public float GetBoostMultiplier()  => _boostMultiplier;
    public float GetDribbleSpeedScale() => HasBall && !_sprintActive ? DribbleSpeedScale : 1f;

    // UI
    private void UpdateCrossoverReadyUI()
    {
        if (CrossoverReadyIndicator == null) return;
        float alpha = _rtHeld && !_sprintActive ? 1f : 0f;
        var c = CrossoverReadyIndicator.color;
        CrossoverReadyIndicator.color = new Color(c.r, c.g, c.b,
            Mathf.Lerp(c.a, alpha, Time.deltaTime * 12f));
    }

    // Public Api
    public void GrabBall() => GainPossession();

    public void GainPossession()
    {
        HasBall = true;

        if (Shooting != null) Shooting.ResetShootingState();

        Vector3 snapPos = _activeSlot != null ? _activeSlot.position : transform.position + Vector3.up * 1f;
        if (Ball != null) Ball.transform.position = snapPos;

        if (_ballRb != null)
        {
            _ballRb.isKinematic     = true;
            _ballRb.useGravity      = false;
            _ballRb.linearVelocity  = Vector3.zero;
            _ballRb.angularVelocity = Vector3.zero;
        }

        _smoothBallPos   = snapPos;
        _ballVelocity    = Vector3.zero;

        _crossoverStreak = 0;
        _boostMultiplier = 1f;
        IsVulnerable     = false;
    }

    public void ReleaseBallForShot()
    {
        HasBall = false;
        if (_ballRb != null) { _ballRb.isKinematic = false; _ballRb.useGravity = true; }
        if (_moveRoutine != null) { StopCoroutine(_moveRoutine); IsDoingMove = false; }
        IsVulnerable = false;
    }

    public void SwitchHand(bool toRight)
    {
        IsRightHanded = toRight;
        _activeSlot   = toRight ? RightHandSlot : LeftHandSlot;
        _bounceCycle  = 0.5f;
    }

    public void UpdateStamina(float pct) => _staminaPercent = pct;
    public void SetSprinting(bool s)     => _isSprinting    = s;

    public void HoldBallTight()
    {
        if (_ballRb    != null) _ballRb.isKinematic = true;
        if (_activeSlot != null) Ball.transform.position = _activeSlot.position;
    }

    private void ShowFeedback(string msg)
    {
        if (DribbleFeedbackText == null) return;
        DribbleFeedbackText.text = msg;
        if (_feedbackRoutine != null) StopCoroutine(_feedbackRoutine);
        _feedbackRoutine = StartCoroutine(ClearFeedback());
    }

    private IEnumerator ClearFeedback()
    {
        yield return new WaitForSeconds(1.5f);
        if (DribbleFeedbackText != null) DribbleFeedbackText.text = "";
    }
}
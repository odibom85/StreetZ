using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using Unity.Networking.Transport.Relay;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Lobbies;
using Unity.Services.Lobbies.Models;
using Unity.Services.Relay;
using Unity.Services.Relay.Models;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

/// <summary>
/// Lobby and Relay manager. Handles the connection flow: anonymous sign-in,
/// host creates Relay allocation + Lobby, client joins via the short relay code.
/// </summary>
public class LobbyManager : MonoBehaviour
{
    // UI References
    [Header("UI Panels")]
    public GameObject MainMenuPanel;
    public GameObject LobbyPanel;
    public GameObject ConnectingPanel;

    [Header("Main Menu UI")]
    public Button   HostButton;
    public Button   JoinButton;
    public TMP_InputField JoinCodeInput;
    public TextMeshProUGUI StatusText;

    [Header("Lobby UI")]
    public TextMeshProUGUI JoinCodeDisplay;   // shows host's code so they can share it
    public TextMeshProUGUI LobbyStatusText;   // "Waiting for opponent..." / "Player 2 joined!"
    public Button          StartGameButton;   // only visible to host
    public Button          LeaveLobbyButton;

    [Header("Settings")]
    [Tooltip("Max players - keep at 2 for 1v1")]
    public int MaxPlayers = 2;
    [Tooltip("Scene to load when game starts")]
    public string GameSceneName = "GameScene";

    // Private State
    private Unity.Services.Lobbies.Models.Lobby _currentLobby;
    private string _relayJoinCode;
    private bool   _isHost = false;

    // Lobby heartbeat - Unity lobbies expire if not kept alive
    private float _heartbeatTimer    = 0f;
    private float _lobbyPollTimer    = 0f;
    private const float HeartbeatInterval = 15f;  // seconds
    private const float LobbyPollInterval =  2f;  // seconds - check if opponent joined

    // Unity
    async void Start()
    {
        // Wire buttons
        if (HostButton)        HostButton.onClick.AddListener(OnHostClicked);
        if (JoinButton)        JoinButton.onClick.AddListener(OnJoinClicked);
        if (StartGameButton)   StartGameButton.onClick.AddListener(OnStartGameClicked);
        if (LeaveLobbyButton)  LeaveLobbyButton.onClick.AddListener(OnLeaveClicked);

        ShowPanel(MainMenuPanel);
        SetStatus("Signing in...");

        await SignInAsync();
    }

    void Update()
    {
        if (_currentLobby == null) return;

        // Keep lobby alive with heartbeat (host only)
        if (_isHost)
        {
            _heartbeatTimer += Time.deltaTime;
            if (_heartbeatTimer >= HeartbeatInterval)
            {
                _heartbeatTimer = 0f;
                _ = SendHeartbeatAsync();
            }
        }

        // Poll lobby to detect when opponent joins
        _lobbyPollTimer += Time.deltaTime;
        if (_lobbyPollTimer >= LobbyPollInterval)
        {
            _lobbyPollTimer = 0f;
            _ = PollLobbyAsync();
        }
    }

    // Sign In
    private async Task SignInAsync()
    {
        try
        {
            // Initialize Unity Gaming Services
            await UnityServices.InitializeAsync();

            if (!AuthenticationService.Instance.IsSignedIn)
                await AuthenticationService.Instance.SignInAnonymouslyAsync();

            SetStatus("Ready");
            Debug.Log($"[Lobby] Signed in as {AuthenticationService.Instance.PlayerId}");
        }
        catch (Exception e)
        {
            SetStatus($"Sign-in failed: {e.Message}");
            Debug.LogError($"[Lobby] Sign-in error: {e}");
        }
    }

    // Host Flow
    private async void OnHostClicked()
    {
        SetStatus("Creating lobby...");
        ShowPanel(ConnectingPanel);

        try
        {
            // 1. Create a Relay allocation (server-side relay for NAT traversal)
            Allocation allocation = await RelayService.Instance.CreateAllocationAsync(MaxPlayers - 1);

            // 2. Get a short join code the other player can type
            _relayJoinCode = await RelayService.Instance.GetJoinCodeAsync(allocation.AllocationId);
            Debug.Log($"[Relay] Join code: {_relayJoinCode}");

            // 3. Configure NGO transport to use Relay
            var transport = NetworkManager.Singleton.GetComponent<UnityTransport>();
            transport.SetRelayServerData(new RelayServerData(allocation, "dtls"));

            // 4. Create a Lobby and store the relay code in its data
            //    This is how the joining player retrieves connection info
            var lobbyOptions = new CreateLobbyOptions
            {
                IsPrivate = false,
                Data = new Dictionary<string, DataObject>
                {
                    {
                        "RelayCode", new DataObject(
                            visibility: DataObject.VisibilityOptions.Public,
                            value: _relayJoinCode)
                    }
                }
            };

            _currentLobby = await LobbyService.Instance.CreateLobbyAsync(
                "StreetZ Game", MaxPlayers, lobbyOptions);

            _isHost = true;

            // 5. Start NGO as host
            NetworkManager.Singleton.StartHost();

            // Show lobby panel with join code
            ShowPanel(LobbyPanel);
            if (JoinCodeDisplay) JoinCodeDisplay.text = $"Code: {_relayJoinCode}";
            if (LobbyStatusText) LobbyStatusText.text = "Waiting for opponent...";
            if (StartGameButton) StartGameButton.gameObject.SetActive(false); // hide until player 2 joins

            Debug.Log($"[Lobby] Created lobby {_currentLobby.Id}");
        }
        catch (Exception e)
        {
            SetStatus($"Host failed: {e.Message}");
            Debug.LogError($"[Lobby] Host error: {e}");
            ShowPanel(MainMenuPanel);
        }
    }

    // Join Flow
    private async void OnJoinClicked()
    {
        string code = JoinCodeInput != null ? JoinCodeInput.text.Trim().ToUpper() : "";
        if (string.IsNullOrEmpty(code))
        {
            SetStatus("Enter a join code first");
            return;
        }

        SetStatus("Joining...");
        ShowPanel(ConnectingPanel);

        try
        {
            // 1. Find lobby by relay join code
            //    Query public lobbies and match the relay code stored in lobby data
            var queryOptions = new QueryLobbiesOptions
            {
                Filters = new List<QueryFilter>
                {
                    new QueryFilter(QueryFilter.FieldOptions.AvailableSlots,
                                   "0", QueryFilter.OpOptions.GT)
                }
            };

            // Join relay directly using the code (simpler than lobby query for 1v1)
            JoinAllocation joinAllocation = await RelayService.Instance.JoinAllocationAsync(code);

            // 2. Configure transport
            var transport = NetworkManager.Singleton.GetComponent<UnityTransport>();
            transport.SetRelayServerData(new RelayServerData(joinAllocation, "dtls"));

            // 3. Find and join the matching lobby
            var lobbies = await LobbyService.Instance.QueryLobbiesAsync(queryOptions);
            foreach (var lobby in lobbies.Results)
            {
                if (lobby.Data.ContainsKey("RelayCode") &&
                    lobby.Data["RelayCode"].Value == code)
                {
                    _currentLobby = await LobbyService.Instance.JoinLobbyByIdAsync(lobby.Id);
                    break;
                }
            }

            _isHost = false;

            // 4. Start NGO as client
            NetworkManager.Singleton.StartClient();

            ShowPanel(LobbyPanel);
            if (JoinCodeDisplay) JoinCodeDisplay.text = $"Code: {code}";
            if (LobbyStatusText) LobbyStatusText.text = "Connected! Waiting for host...";
            if (StartGameButton) StartGameButton.gameObject.SetActive(false); // clients can't start

            Debug.Log("[Lobby] Joined successfully");
        }
        catch (Exception e)
        {
            SetStatus($"Join failed: {e.Message}");
            Debug.LogError($"[Lobby] Join error: {e}");
            ShowPanel(MainMenuPanel);
        }
    }

    // Lobby Polling- detect when opponent joins
    private async Task PollLobbyAsync()
    {
        if (_currentLobby == null) return;

        try
        {
            _currentLobby = await LobbyService.Instance.GetLobbyAsync(_currentLobby.Id);

            int playerCount = _currentLobby.Players.Count;

            if (_isHost && LobbyStatusText)
            {
                if (playerCount >= MaxPlayers)
                {
                    LobbyStatusText.text = "Opponent joined! Ready to start.";
                    if (StartGameButton) StartGameButton.gameObject.SetActive(true);
                }
                else
                {
                    LobbyStatusText.text = "Waiting for opponent...";
                }
            }
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[Lobby] Poll error: {e.Message}");
        }
    }

    // Heartbeat- keep lobby alive
    private async Task SendHeartbeatAsync()
    {
        if (_currentLobby == null) return;
        try
        {
            await LobbyService.Instance.SendHeartbeatPingAsync(_currentLobby.Id);
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[Lobby] Heartbeat error: {e.Message}");
        }
    }

    // Start Game- host only
    private void OnStartGameClicked()
    {
        if (!_isHost) return;

        int connected = NetworkManager.Singleton.ConnectedClients.Count;
        Debug.Log($"[Lobby] Start Game clicked - {connected} NGO clients connected");

        if (connected < MaxPlayers)
        {
            if (LobbyStatusText)
                LobbyStatusText.text = $"Still connecting... ({connected}/{MaxPlayers}) - try again in a moment";
            Debug.LogWarning("[Lobby] Not all clients connected to NGO yet");
            return;
        }

        Debug.Log("[Lobby] Loading game scene for all clients...");
        NetworkManager.Singleton.SceneManager.LoadScene(
            GameSceneName,
            UnityEngine.SceneManagement.LoadSceneMode.Single);
    }

    // Leave Lobby
    private async void OnLeaveClicked()
    {
        try
        {
            if (_currentLobby != null)
            {
                if (_isHost)
                    await LobbyService.Instance.DeleteLobbyAsync(_currentLobby.Id);
                else
                    await LobbyService.Instance.RemovePlayerAsync(
                        _currentLobby.Id,
                        AuthenticationService.Instance.PlayerId);

                _currentLobby = null;
            }

            NetworkManager.Singleton.Shutdown();
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[Lobby] Leave error: {e.Message}");
        }

        ShowPanel(MainMenuPanel);
        SetStatus("Ready");
    }

    // Helpers
    private void ShowPanel(GameObject panel)
    {
        if (MainMenuPanel)   MainMenuPanel.SetActive(panel == MainMenuPanel);
        if (LobbyPanel)      LobbyPanel.SetActive(panel == LobbyPanel);
        if (ConnectingPanel) ConnectingPanel.SetActive(panel == ConnectingPanel);
    }

    private void SetStatus(string msg)
    {
        if (StatusText) StatusText.text = msg;
        Debug.Log($"[Lobby] {msg}");
    }

    // Clean up on quit
    private async void OnDestroy()
    {
        if (_currentLobby != null && _isHost)
        {
            try { await LobbyService.Instance.DeleteLobbyAsync(_currentLobby.Id); }
            catch { }
        }
    }
}
using Unity.Netcode;
using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Server-side spawner. Spawns one player per connected client at the appropriate
/// spawn point and wires up component references that need to be set in code.
/// </summary>
public class NetworkSpawnManager : NetworkBehaviour
{
    [Header("Prefabs")]
    public GameObject PlayerPrefab;
    public GameObject BallPrefab;

    [Header("Spawn Points - assign in Inspector")]
    public Transform PlayerSpawn;   // Team A position 1
    public Transform AISpawn;       // Team B position 1

    [Header("Extra Spawn Points (for 3v3 / 4v4)")]
    public Transform[] ExtraSpawns; // optional additional positions

    [Header("Ball Spawn")]
    public Transform BallSpawn;

    [Header("Scene References")]
    public Transform HoopTarget;

    // Prevent double-spawning
    private HashSet<ulong> _spawned = new HashSet<ulong>();

    public override void OnNetworkSpawn()
    {
        if (!IsServer) return;

        Debug.Log($"[SpawnManager] OnNetworkSpawn - {NetworkManager.Singleton.ConnectedClientsIds.Count} clients connected");

        NetworkManager.Singleton.OnClientConnectedCallback += OnClientConnected;

        SpawnBall();

        // Spawn all clients that are already connected
        foreach (ulong id in NetworkManager.Singleton.ConnectedClientsIds)
            SpawnPlayer(id);
    }

    public override void OnNetworkDespawn()
    {
        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.OnClientConnectedCallback -= OnClientConnected;
    }

    private void OnClientConnected(ulong clientId)
    {
        if (!IsServer) return;
        SpawnPlayer(clientId);
    }

    private void SpawnPlayer(ulong clientId)
    {
        if (_spawned.Contains(clientId)) return;
        _spawned.Add(clientId);

        int index         = _spawned.Count - 1;
        Transform spawnPt = PickSpawnPoint(index);

        if (spawnPt == null)
        {
            Debug.LogError($"[SpawnManager] No spawn point for index {index}.");
            return;
        }

        Debug.Log($"[SpawnManager] Spawning client {clientId} at {spawnPt.name}");

        GameObject p = Instantiate(PlayerPrefab, spawnPt.position, spawnPt.rotation);

        // Wire up all references before network spawn

        // Get all components
        var ctrl        = p.GetComponent<PlayerController>();
        var shooting    = p.GetComponent<PlayerShooting>();
        var ballHandler = p.GetComponent<PlayerBallHandler>();
        var stamina     = p.GetComponent<PlayerStamina>();
        var defense     = p.GetComponent<PlayerDefense>();
        var pickup      = p.GetComponent<BallPickup>();

        // HoopTarget → PlayerController + PlayerShooting
        if (HoopTarget != null)
        {
            if (ctrl     != null) ctrl.HoopTarget     = HoopTarget;
            if (shooting != null) shooting.HoopTarget  = HoopTarget;
        }

        // Ball → PlayerBallHandler
        GameObject ball = GameObject.FindGameObjectWithTag("Ball");
        if (ball != null)
        {
            if (ballHandler != null) ballHandler.Ball = ball;
        }
        else
        {
            Debug.LogWarning("[SpawnManager] Ball not found by tag - will retry in NetworkPlayerSetup");
        }

        // Cross-references between sibling components on this player

        // PlayerShooting needs BallHandler and Stamina
        if (shooting != null)
        {
            if (shooting.BallHandler == null && ballHandler != null)
                shooting.BallHandler = ballHandler;
            if (shooting.Stamina == null && stamina != null)
                shooting.Stamina = stamina;
        }

        // PlayerBallHandler needs Shooting and Stamina
        if (ballHandler != null)
        {
            if (ballHandler.Shooting == null && shooting != null)
                ballHandler.Shooting = shooting;
            if (ballHandler.Stamina == null && stamina != null)
                ballHandler.Stamina = stamina;
        }

        // PlayerStamina needs BallHandler, Defense, Shooting
        if (stamina != null)
        {
            if (stamina.BallHandler    == null && ballHandler != null) stamina.BallHandler    = ballHandler;
            if (stamina.DefenseScript  == null && defense     != null) stamina.DefenseScript  = defense;
            if (stamina.ShootingScript == null && shooting    != null) stamina.ShootingScript = shooting;
            if (stamina.CC             == null) stamina.CC = p.GetComponent<CharacterController>();
        }

        // PlayerDefense needs ShootingScript
        if (defense != null)
        {
            if (defense.ShootingScript == null && shooting != null)
                defense.ShootingScript = shooting;
        }

        // BallPickup needs BallHandler and ShootingScript
        if (pickup != null)
        {
            if (pickup.BallHandler    == null && ballHandler != null) pickup.BallHandler    = ballHandler;
            if (pickup.ShootingScript == null && shooting    != null) pickup.ShootingScript = shooting;
        }

        // Spawn as player object
        var netObj = p.GetComponent<NetworkObject>();
        if (netObj != null)
            netObj.SpawnAsPlayerObject(clientId);
        else
        {
            Debug.LogError("[SpawnManager] PlayerPrefab missing NetworkObject!");
            Destroy(p);
        }
    }

    private Transform PickSpawnPoint(int index)
    {
        return index switch
        {
            0 => PlayerSpawn,
            1 => AISpawn,
            _ => ExtraSpawns != null && index - 2 < ExtraSpawns.Length
                 ? ExtraSpawns[index - 2]
                 : AISpawn
        };
    }

    private void SpawnBall()
    {
        if (BallPrefab == null) { Debug.LogWarning("[SpawnManager] BallPrefab not assigned"); return; }
        Vector3 pos     = BallSpawn != null ? BallSpawn.position : Vector3.zero;
        GameObject ball = Instantiate(BallPrefab, pos, Quaternion.identity);
        var netObj      = ball.GetComponent<NetworkObject>();
        if (netObj != null) netObj.Spawn();
    }
}
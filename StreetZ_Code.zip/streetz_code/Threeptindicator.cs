using UnityEngine;
using TMPro;

/// <summary>
/// Attach to an empty GameObject near the hoop.
///   1. Draws a visible arc/ring around the hoop at ThreePointRadius in the Scene
///      using a LineRenderer so you can see it in Play mode too.
/// </summary>
[RequireComponent(typeof(LineRenderer))]
public class ThreePtIndicator : MonoBehaviour
{
    [Header("References")]
    public Transform Player;
    public Transform HoopCenter;

    [Header("Arc Settings")]
    [Tooltip("Must match HoopSensor.ThreePointLine (default NBA = 7.25m)")]
    public float ThreePointRadius = 7.25f;

    [Tooltip("How many points to use when drawing the arc (more = smoother)")]
    public int   ArcSegments      = 64;

    [Tooltip("Height above the floor to draw the ring")]
    public float RingHeight        = 0.05f;

    [Header("Colours")]
    public Color InsideColor  = new Color(1f, 1f, 1f, 0.35f);   // inside arc = 2pt (subtle white)
    public Color OutsideColor = new Color(0f, 0.8f, 1f, 0.85f); // outside arc = 3pt (bright cyan)

    [Header("UI")]
    public TextMeshProUGUI ShotTypeText;   // small label e.g. "3PT ●" shown near shot meter

    // Public read
    public bool IsBehindArc { get; private set; }

    // Private
    private LineRenderer _lr;

    void Awake()
    {
        _lr = GetComponent<LineRenderer>();
        ConfigureLineRenderer();
        DrawArc();
    }

    void Update()
    {
        if (Player == null || HoopCenter == null) return;

        // Flat distance (ignore height)
        float dist = Vector3.Distance(
            new Vector3(Player.position.x,    0f, Player.position.z),
            new Vector3(HoopCenter.position.x, 0f, HoopCenter.position.z));

        IsBehindArc = dist > ThreePointRadius;

        // Update arc colour live
        Color c = IsBehindArc ? OutsideColor : InsideColor;
        _lr.startColor = c;
        _lr.endColor   = c;

        // Update UI label
        if (ShotTypeText != null)
            ShotTypeText.text = IsBehindArc ? "3PT" : "2PT";
    }

    // Setup
    private void ConfigureLineRenderer()
    {
        _lr.useWorldSpace     = true;
        _lr.loop              = true;
        _lr.startWidth        = 0.12f;
        _lr.endWidth          = 0.12f;
        _lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        _lr.receiveShadows    = false;
        _lr.material          = new Material(Shader.Find("Sprites/Default"));
        // positionCount is set inside DrawArc, not here
    }

    private void DrawArc()
    {
        if (_lr == null || HoopCenter == null) return;

        // Always clamp to a safe minimum before writing any positions
        int segments = Mathf.Max(ArcSegments, 3);

        _lr.positionCount = segments;   // set count HERE, not in Configure

        Vector3 center = new Vector3(HoopCenter.position.x, RingHeight, HoopCenter.position.z);

        for (int i = 0; i < segments; i++)
        {
            float angle = (i / (float)segments) * Mathf.PI * 2f;
            float x     = center.x + Mathf.Cos(angle) * ThreePointRadius;
            float z     = center.z + Mathf.Sin(angle) * ThreePointRadius;
            _lr.SetPosition(i, new Vector3(x, RingHeight, z));
        }
    }

    // Redraw if values change in Inspector during Play or Edit mode
    void OnValidate()
    {
        if (_lr == null) _lr = GetComponent<LineRenderer>();
        if (_lr == null || HoopCenter == null) return;
        // Ensure positionCount is always in sync before drawing
        _lr.positionCount = Mathf.Max(ArcSegments, 3);
        DrawArc();
    }

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        if (HoopCenter == null) return;
        Gizmos.color = Color.cyan;
        Vector3 prev = Vector3.zero;
        for (int i = 0; i <= 64; i++)
        {
            float angle = (i / 64f) * Mathf.PI * 2f;
            Vector3 pt  = HoopCenter.position
                        + new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle)) * ThreePointRadius;
            pt.y = HoopCenter.position.y;
            if (i > 0) Gizmos.DrawLine(prev, pt);
            prev = pt;
        }
    }
#endif
}
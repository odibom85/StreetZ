using UnityEngine;
using UnityEngine.InputSystem;
using Unity.Netcode;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : NetworkBehaviour
{
    [Header("Multiplayer / Local Settings")]
    public int PlayerIndex = 0; // 0 for Player 1, 1 for Player 2
    public bool IsLocalTesting = true; 

    [Header("Movement Settings")]
    public float MoveSpeed        = 5f;
    public float SprintMultiplier = 1.5f;
    public float Gravity          = -18f;
    public float RotationSpeed    = 12f;

    [Header("References")]
    public Transform CameraTransform;
    public Transform HoopTarget;       

    private CharacterController _cc;
    private PlayerBallHandler   _ballHandler;
    private PlayerStamina       _stamina;
    private NetworkObject       _netObj;        
    private Vector3 _moveDir;
    private float   _verticalVelocity;

    void Awake()
    {
        _cc          = GetComponent<CharacterController>();
        _ballHandler = GetComponent<PlayerBallHandler>();
        _stamina     = GetComponent<PlayerStamina>();
        _netObj      = GetComponent<NetworkObject>();
        
        if (CameraTransform == null && Camera.main != null)
            CameraTransform = Camera.main.transform;
    }

    void Update()
    {
        // Bypass ownership check if we are testing two players on one machine
        if (!IsLocalTesting)
        {
            if (_netObj != null && !_netObj.IsOwner) return;
        }

        if (CameraTransform == null) return;

        // --- Device aware input ---
        Gamepad gp = (Gamepad.all.Count > PlayerIndex) ? Gamepad.all[PlayerIndex] : null;
        Keyboard kb = Keyboard.current;

        Vector2 moveInput = Vector2.zero;
        bool isSprinting = false;

        if (gp != null)
        {
            moveInput = gp.leftStick.ReadValue();
            isSprinting = gp.leftTrigger.isPressed;
        }
        else if (kb != null)
        {
            // P1 uses wasd, P2 uses Arrows
            if (PlayerIndex == 0)
            {
                float x = (kb.dKey.isPressed ? 1 : 0) - (kb.aKey.isPressed ? 1 : 0);
                float y = (kb.wKey.isPressed ? 1 : 0) - (kb.sKey.isPressed ? 1 : 0);
                moveInput = new Vector2(x, y);
                isSprinting = kb.leftShiftKey.isPressed;
            }
            else
            {
                float x = (kb.rightArrowKey.isPressed ? 1 : 0) - (kb.leftArrowKey.isPressed ? 1 : 0);
                float y = (kb.upArrowKey.isPressed ? 1 : 0) - (kb.downArrowKey.isPressed ? 1 : 0);
                moveInput = new Vector2(x, y);
                isSprinting = kb.rightShiftKey.isPressed;
            }
        }

        // 2. Movement Logic
        Vector3 forward = CameraTransform.forward;
        Vector3 right   = CameraTransform.right;
        forward.y = 0f;
        right.y   = 0f;
        forward.Normalize();
        right.Normalize();

        _moveDir = (forward * moveInput.y + right * moveInput.x).normalized;

        float currentSpeed = MoveSpeed;
        if (isSprinting && _stamina != null && _stamina.StaminaPercent > 0)
        {
            currentSpeed *= SprintMultiplier;
            _stamina.DrainSprint();
        }

        if (_cc.isGrounded)
        {
            _verticalVelocity = -2f;
        }
        else
        {
            _verticalVelocity += Gravity * Time.deltaTime;
        }

        Vector3 finalVelocity = (_moveDir * currentSpeed) + (Vector3.up * _verticalVelocity);
        _cc.Move(finalVelocity * Time.deltaTime);

        // 3. Rotation
        if (_cc.enabled)
        {
            bool hasBall = _ballHandler != null && _ballHandler.HasBall;

            if (hasBall && HoopTarget != null)
            {
                Vector3 toHoop = HoopTarget.position - transform.position;
                toHoop.y = 0f;
                if (toHoop.sqrMagnitude > 0.01f)
                {
                    Quaternion targetRot = Quaternion.LookRotation(toHoop);
                    transform.rotation   = Quaternion.Slerp(transform.rotation, targetRot, RotationSpeed * Time.deltaTime);
                }
            }
            else if (_moveDir.magnitude > 0.1f)
            {
                Quaternion targetRot = Quaternion.LookRotation(_moveDir);
                transform.rotation   = Quaternion.Slerp(transform.rotation, targetRot, RotationSpeed * Time.deltaTime);
            }
        }

        if (_ballHandler != null) _ballHandler.SetSprinting(isSprinting);
    }
}
using Unity.Netcode;
using UnityEngine;
using TMPro;

/// <summary>
/// Small HUD label showing connection state and round-trip time, with colour grading
/// based on ping (green/amber/red).
/// </summary>
public class ConnectionStatusIndicator : MonoBehaviour
{
    // UI
    [Header("UI")]
    [Tooltip("Text label showing connection status and ping")]
    public TextMeshProUGUI StatusText;

    // Settings
    [Header("Settings")]
    [Tooltip("How often (seconds) to refresh the readout")]
    public float UpdateInterval = 0.5f;

    [Tooltip("Show round-trip time next to the status text")]
    public bool ShowPing = true;

    // Colours
    [Header("Colours")]
    public Color ConnectedColor    = new Color(0.3f, 1f,   0.3f); // green
    public Color ConnectingColor   = new Color(1f,   0.8f, 0.2f); // amber
    public Color DisconnectedColor = new Color(1f,   0.3f, 0.3f); // red
    public Color HighPingColor     = new Color(1f,   0.8f, 0.2f); // yellow
    public Color BadPingColor      = new Color(1f,   0.3f, 0.3f); // red

    [Header("Ping Thresholds (ms)")]
    [Tooltip("Ping below this value is shown in the normal connected colour")]
    public int GoodPingMs = 60;
    [Tooltip("Ping below this value is shown in yellow. Above = red.")]
    public int OkayPingMs = 150;

    // Private
    private float _nextUpdate;

    // Unity
    void Update()
    {
        if (Time.unscaledTime < _nextUpdate) return;
        _nextUpdate = Time.unscaledTime + UpdateInterval;

        if (StatusText == null) return;
        Refresh();
    }

    private void Refresh()
    {
        var nm = NetworkManager.Singleton;

        // No NetworkManager in scene or not running - show disconnected
        if (nm == null || !nm.IsListening)
        {
            SetStatus("● Offline", DisconnectedColor);
            return;
        }

        // Still negotiating the connection
        if (!nm.IsConnectedClient && !nm.IsServer)
        {
            SetStatus("● Connecting...", ConnectingColor);
            return;
        }

        // Connected - format role + optional ping
        string role = nm.IsServer ? "HOST" : "CLIENT";

        if (!ShowPing)
        {
            SetStatus($"● {role}", ConnectedColor);
            return;
        }

        int pingMs = GetPingMs(nm);
        Color col  = PingColour(pingMs);

        // "◆ Host   42ms"
        SetStatus($"● {role}   {pingMs}ms", col);
    }

    // Ping Reading
    // Unity Transport exposes RTT per-client. For the host, we read the
    // first connected client's RTT (i.e. the opponent's ping). For a
    // client, we read the host's RTT (i.e. our ping to the host).
    private int GetPingMs(NetworkManager nm)
    {
        if (nm.NetworkConfig == null || nm.NetworkConfig.NetworkTransport == null)
            return 0;

        var transport = nm.NetworkConfig.NetworkTransport;

        if (nm.IsServer)
        {
            // Server: report RTT to the first non-host client
            foreach (ulong id in nm.ConnectedClientsIds)
            {
                if (id == NetworkManager.ServerClientId) continue;
                return (int)transport.GetCurrentRtt(id);
            }
            return 0; // no remote clients - playing solo
        }
        else
        {
            // Client: RTT to the server
            return (int)transport.GetCurrentRtt(NetworkManager.ServerClientId);
        }
    }

    private Color PingColour(int ms)
    {
        if (ms <= GoodPingMs)  return ConnectedColor;
        if (ms <= OkayPingMs)  return HighPingColor;
        return BadPingColor;
    }

    // Helpers
    private void SetStatus(string msg, Color col)
    {
        StatusText.text  = msg;
        StatusText.color = col;
    }
}
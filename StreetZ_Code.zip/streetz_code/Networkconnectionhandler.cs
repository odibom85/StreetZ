using Unity.Netcode;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System.Collections;

/// <summary>
/// Disconnect handling. Detects when a client drops, pauses the match, gives a
/// grace period for reconnection, and forfeits the match if the client doesn't return.
/// </summary>
public class NetworkConnectionHandler : NetworkBehaviour
{
    // UI
    [Header("UI - disconnect banner")]
    [Tooltip("Panel shown when a disconnect is detected")]
    public GameObject       DisconnectPanel;
    [Tooltip("Text inside the panel (countdown, status messages)")]
    public TextMeshProUGUI  DisconnectText;
    [Tooltip("Button to bail out of a dead match manually")]
    public Button           ReturnToMenuButton;

    // Settings
    [Header("Settings")]
    [Tooltip("Seconds to wait for the client to reconnect before ending the match")]
    public float  GracePeriodSeconds = 5f;
    [Tooltip("Main-menu scene to return to on disconnect")]
    public string MainMenuSceneName  = "MainMenu";

    // Replicated State
    /// <summary>
    /// True while the server is holding the match open for a potentially-
    /// reconnecting client. Replicated so the remaining client shows the
    /// same pause overlay without needing a separate RPC.
    /// </summary>
    public NetworkVariable<bool> IsGamePaused = new NetworkVariable<bool>(
        false,
        readPerm:  NetworkVariableReadPermission.Everyone,
        writePerm: NetworkVariableWritePermission.Server);

    // Private
    private Coroutine _graceCoroutine;
    private bool      _returning = false;   // prevent double menu-returns

    // Lifecycle
    public override void OnNetworkSpawn()
    {
        IsGamePaused.OnValueChanged += OnPauseChanged;

        if (DisconnectPanel     != null) DisconnectPanel.SetActive(false);
        if (ReturnToMenuButton  != null) ReturnToMenuButton.onClick.AddListener(ReturnToMenu);

        // Subscribe on both server and client - the callback fires differently
        // on each side (see OnClientDisconnected below).
        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.OnClientDisconnectCallback += OnClientDisconnected;
    }

    public override void OnNetworkDespawn()
    {
        IsGamePaused.OnValueChanged -= OnPauseChanged;

        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.OnClientDisconnectCallback -= OnClientDisconnected;

        if (ReturnToMenuButton != null)
            ReturnToMenuButton.onClick.RemoveListener(ReturnToMenu);
    }

    // Disconnect Callback
    // Behaviour branches based on who this instance is:
    // - Server: the disconnected client is the opponent. Start grace period.
    // - Client: either our own disconnect, or the server went away.
    //             Either way, the session is dead - return to menu.
    private void OnClientDisconnected(ulong clientId)
    {
        if (IsServer)
        {
            // Ignore our own disconnect callback (fires on shutdown).
            if (clientId == NetworkManager.ServerClientId) return;

            Debug.Log($"[Net] Client {clientId} disconnected - starting grace period");
            IsGamePaused.Value = true;

            if (_graceCoroutine != null) StopCoroutine(_graceCoroutine);
            _graceCoroutine = StartCoroutine(GracePeriodRoutine(clientId));
        }
        else
        {
            // Client side: this fires either because WE got kicked/disconnected,
            // or because the host terminated the session. Either way, the
            // multiplayer session is no longer usable.
            if (_returning) return;

            // If the server attached a reason via DisconnectClient(id, reason),
            // NGO exposes it via NetworkManager.DisconnectReason. Fall back
            // to a generic message if no reason was provided.
            string reason = NetworkManager.DisconnectReason;
            if (string.IsNullOrEmpty(reason))
                reason = "Lost connection to host";

            Debug.Log($"[Net] Disconnected: {reason}");
            ShowPanel(reason);
            StartCoroutine(ReturnAfterDelay(3f));
        }
    }

    // Grace period (server only)
    //
    // NGO does not re-dispatch a new Connect callback for a client that
    // reconnects with the same clientId; instead the client would get a
    // fresh clientId. Proper reconnection support would require Unity
    // Relay to preserve the allocation and session-level matchmaking to
    // re-associate the player. Listed as future work in the report.
    //
    // For now we give the client a small window to reappear (network
    // hiccup recovery), then forfeit the match.
    private IEnumerator GracePeriodRoutine(ulong missingClientId)
    {
        float elapsed = 0f;
        while (elapsed < GracePeriodSeconds)
        {
            if (NetworkManager.ConnectedClients.ContainsKey(missingClientId))
            {
                Debug.Log("[Net] Opponent reconnected within grace period");
                IsGamePaused.Value = false;
                HidePanelClientRpc();
                yield break;
            }

            int remaining = Mathf.CeilToInt(GracePeriodSeconds - elapsed);
            ShowPanelClientRpc(
                $"Opponent disconnected\nEnding match in {remaining}...");

            elapsed += Time.deltaTime;
            yield return null;
        }

        // Grace period elapsed - match is over.
        ShowPanelClientRpc("Opponent disconnected\nMatch forfeited");
        yield return new WaitForSeconds(2f);
        ReturnEveryoneToMenuClientRpc();
    }

    // Server → client RPCs
    [Rpc(SendTo.Everyone)]
    private void ShowPanelClientRpc(string msg)
    {
        ShowPanel(msg);
    }

    [Rpc(SendTo.Everyone)]
    private void HidePanelClientRpc()
    {
        if (DisconnectPanel != null) DisconnectPanel.SetActive(false);
    }

    [Rpc(SendTo.Everyone)]
    private void ReturnEveryoneToMenuClientRpc()
    {
        if (_returning) return;
        StartCoroutine(ReturnAfterDelay(0.5f));
    }

    // UI helpers
    private void OnPauseChanged(bool oldV, bool newV)
    {
        // Optional: freeze input / gameplay while paused.
        // The BasketballGameManager could check IsGamePaused before ticking
        // the shot clock. Left as a hook for future expansion.
        Time.timeScale = newV ? 0.25f : 1f;
    }

    private void ShowPanel(string msg)
    {
        if (DisconnectPanel != null) DisconnectPanel.SetActive(true);
        if (DisconnectText  != null) DisconnectText.text = msg;
    }

    private IEnumerator ReturnAfterDelay(float seconds)
    {
        _returning = true;
        // Use realtime so Time.timeScale = 0.25 doesn't slow the return.
        yield return new WaitForSecondsRealtime(seconds);
        ReturnToMenu();
    }

    // Menu Return
    private void ReturnToMenu()
    {
        // Restore time scale in case we were paused
        Time.timeScale = 1f;

        // Shut down NGO cleanly - releases the Relay allocation, closes
        // sockets, and fires disconnect callbacks on any still-connected peers.
        if (NetworkManager.Singleton != null && NetworkManager.Singleton.IsListening)
            NetworkManager.Singleton.Shutdown();

        // Load the main menu scene locally (non-networked, so we use the
        // regular SceneManager, not NetworkManager.SceneManager).
        SceneManager.LoadScene(MainMenuSceneName);
    }
}
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using Unity.Cinemachine;
using Unity.Netcode;

/// <summary>
/// Player shooting script. Handles jump shots, layups, dunks, and the cinematic camera
/// that swings into place when the player charges up a shot.
/// </summary>
public class PlayerShooting : MonoBehaviour
{
    // References
    [Header("References")]
    public PlayerBallHandler   BallHandler;
    public Transform           HoopTarget;
    public Transform           OpponentTransform;
    public PlayerStamina       Stamina;
    public CinemachineCamera   VCam;          // main game camera
    public CinemachineCamera   ShotVCam;      // dedicated cinematic shot camera
    public Transform           ShotCamRig;   // empty GO the shot cam sits on
    private CharacterController _cc;
    private TrailRenderer       _ballTrail;

    // Jump Shot
    [Header("Jump Shot")]
    public float PerfectWindow    = 0.38f;
    public float GoodWindow       = 0.18f;
    public float JumpRiseTime     = 0.22f;
    public float JumpHangTime     = 0.28f;
    public float JumpFallTime     = 0.18f;
    public float JumpHeight       = 1.4f;
    public float BallReleaseHeight = 0.6f;

    // Layup
    [Header("Layup")]
    public float MaxLayupDistance   = 5.5f;
    public float LayupMinSpeed     = 1.2f;
    public float LayupPerfectWindow = 0.3f;
    public float LayupJumpHeight    = 1.7f;
    public float LayupForwardLeap   = 3.2f;

    // Dunk
    [Header("Dunk")]
    public float MaxDunkDistance      = 3.5f;
    public float RequiredSpeedForDunk = 3.5f;
    public float DunkJumpHeight       = 2.5f;
    public float DunkPerfectWindow    = 0.5f;
    public float DunkSpeed            = 7f;
    public Transform DunkSlamPoint;

    // Defense
    [Header("Defense")]
    public float MaxContestDist  = 4.5f;
    public float BaseBlockChance = 0.3f;
    public float BlockCooldown   = 1.2f;
    public bool  IsDefending     { get; set; }
    public bool  IsInBlockPose   { get; private set; }
    private float _blockTimer;

    // 3pt Line
    [Header("Three Point Line")]
    public ThreePtIndicator ThreePtLine;
    public float ThreePointRadius = 7.25f;

    // Cinematic Shot Camera
    [Header("Cinematic Shot Camera")]
    public int   ShotCamPriority     = 20;
    public float ShotCamBehindDist   = 4.5f;
    public float ShotCamHeight       = 3.2f;
    public float ShotCamPullbackDist = 9f;
    public float ShotCamPullbackHeight = 5f;
    public float ShotCamSmooth       = 0.12f;
    public float ShotCamReturnDelay  = 1.4f;

    // Normal Camera FOV
    [Header("Camera FOV")]
    public float NormalFOV        = 60f;
    public float ChargeFOV        = 38f;
    public float MidrangeZoomFOV  = 32f;
    public float PullbackFOV      = 44f;
    public float ZoomSpeed        = 6f;
    private float _targetFOV;

    [Header("Midrange Arc")]
    public float MidrangeArcDuration = 1.1f;

    private bool _lastShotWasMidrange = false;
    private bool _lastShotWasPerfect  = false;

    // UI
    [Header("UI")]
    public GameObject      MeterRoot;
    public Image           MeterFill;
    public Image           GreenZoneMarker;
    public Image           TimingFlash;
    public TextMeshProUGUI FeedbackText;
    public TextMeshProUGUI TimingLabel;
    public Color NormalColor    = Color.yellow;
    public Color LayupBaseColor = Color.cyan;
    public Color DunkBaseColor  = Color.magenta;
    public Color PerfectColor   = Color.green;
    public Color GoodColor      = new Color(0.6f, 1f, 0.2f);
    public Color BadColor       = Color.red;

    // State
    [Header("State - Read Only")]
    public bool IsCharging     = false;
    public bool IsDrivingLayup = false;
    public bool IsDunking      = false;

    private float   _chargeTimer;
    private float   _currentPerfectWindow;
    private Vector3 _initialPos;
    private bool    _inShotCam = false;
    private Vector3 _shotCamVelocity;
    private float   _currentContestLevel;
    private NetworkObject _netObj;

    // Jump State
    private enum JumpPhase { None, Rising, Hanging, Falling }
    private JumpPhase _jumpPhase = JumpPhase.None;
    private float     _jumpPhaseTimer;
    private float     _jumpStartY;

    // Direct Input Polling State
    private bool _prevShootHeld  = false;
    private bool _prevLayupHeld  = false;

    // Unity
    void Awake()
    {
        _cc        = GetComponent<CharacterController>();
        _netObj    = GetComponent<NetworkObject>();
        _targetFOV = NormalFOV;
        if (BallHandler?.Ball != null)
            _ballTrail = BallHandler.Ball.GetComponent<TrailRenderer>();
        if (Stamina == null) Stamina = GetComponent<PlayerStamina>();

        if (ShotVCam != null) ShotVCam.Priority = 0;
        if (MeterRoot != null) MeterRoot.SetActive(false);
    }

    void Update()
    {
        if (_netObj != null && !_netObj.IsOwner) return;

        if (_blockTimer > 0) _blockTimer -= Time.deltaTime;

        PollInput();
        TickJump();
        TickShotCamera();
        TickMainCameraFOV();
    }

    // Direct Input Polling- replaces all OnXxx(InputValue) callbacks
    private void PollInput()
    {
        if (!gameObject.CompareTag("Player")) return;

        Gamepad  gp = Gamepad.current;
        Keyboard kb = Keyboard.current;

        // Shoot - Button West (X on Xbox / Square on PS) or Space
        bool shootHeld = (gp != null && gp.buttonWest.isPressed)
                      || (kb != null && kb.spaceKey.isPressed);

        if (shootHeld && !_prevShootHeld)
            HandleShootInput(true);    // pressed this frame
        else if (!shootHeld && _prevShootHeld)
            HandleShootInput(false);   // released this frame

        _prevShootHeld = shootHeld;

        // Layup - Button North (Y / Triangle) or F
        bool layupHeld = (gp != null && gp.buttonNorth.isPressed)
                      || (kb != null && kb.fKey.isPressed);

        if (layupHeld && !_prevLayupHeld)
            HandleLayupInput(true);
        else if (!layupHeld && _prevLayupHeld)
            HandleLayupInput(false);

        _prevLayupHeld = layupHeld;

        // Block - Right Shoulder (RB / R1) or R
        bool blockPressed = (gp != null && gp.rightShoulder.wasPressedThisFrame)
                         || (kb != null && kb.rKey.wasPressedThisFrame);

        if (blockPressed && BallHandler != null && !BallHandler.HasBall)
            TryBlock();
    }

    // Shoot Input Handling
    private void HandleShootInput(bool isPressed)
    {
        if (BallHandler == null || HoopTarget == null) return;

        if (isPressed && BallHandler.HasBall && !IsCharging)
        {
            float dist  = Vector3.Distance(transform.position, HoopTarget.position);
            float speed = _cc != null ? _cc.velocity.magnitude : 0f;
            float boostedSpeed = speed * (BallHandler?.GetBoostMultiplier() ?? 1f);

            if (dist <= MaxDunkDistance && boostedSpeed >= RequiredSpeedForDunk)
                BeginCharging(false, true);
            else
                BeginCharging(false, false);
        }
        else if (!isPressed && IsCharging && !IsDrivingLayup && !IsDunking)
        {
            ReleaseShot();
        }
    }

    private void HandleLayupInput(bool isPressed)
    {
        if (BallHandler == null || HoopTarget == null) return;

        if (isPressed && BallHandler.HasBall && !IsCharging)
        {
            float dist  = Vector3.Distance(transform.position, HoopTarget.position);
            float speed = _cc != null ? _cc.velocity.magnitude : 0f;

            if (dist <= MaxDunkDistance && speed >= RequiredSpeedForDunk)
                BeginCharging(false, true);
            else if (dist <= MaxLayupDistance && speed >= LayupMinSpeed)
                BeginCharging(true, false);
            else
                BeginCharging(false, false);
        }
        else if (!isPressed && IsCharging && (IsDrivingLayup || IsDunking))
        {
            ReleaseShot();
        }
    }

    // Begin Charging
    private void BeginCharging(bool forceLayup, bool forceDunk)
    {
        IsCharging     = true;
        IsDrivingLayup = forceLayup;
        IsDunking      = forceDunk;
        _chargeTimer   = 0f;
        _initialPos    = transform.position;
        _jumpStartY    = transform.position.y;

        _currentPerfectWindow = IsDunking      ? DunkPerfectWindow :
                                IsDrivingLayup ? LayupPerfectWindow :
                                PerfectWindow;

        if (_cc != null) _cc.enabled = false;

        _jumpPhase      = JumpPhase.Rising;
        _jumpPhaseTimer = 0f;

        if (MeterRoot != null)
        {
            MeterRoot.SetActive(true);
            MeterFill.fillAmount = 0f;
            MeterFill.color = IsDunking ? DunkBaseColor :
                              IsDrivingLayup ? LayupBaseColor : NormalColor;

            if (GreenZoneMarker != null)
            {
                GreenZoneMarker.gameObject.SetActive(true);
                GreenZoneMarker.color = PerfectColor;
            }
            if (TimingFlash  != null) TimingFlash.color  = new Color(1,1,1,0);
            if (TimingLabel  != null) TimingLabel.text   = "";
        }

        if (_ballTrail != null) _ballTrail.emitting = false;

        float dist2D = HoopTarget != null ? Vector3.Distance(
            new Vector3(transform.position.x, 0, transform.position.z),
            new Vector3(HoopTarget.position.x, 0, HoopTarget.position.z)) : 0f;
        _lastShotWasMidrange = !IsDrivingLayup && !IsDunking && dist2D <= ThreePointRadius;
        _targetFOV = _lastShotWasMidrange ? MidrangeZoomFOV : ChargeFOV;

        ActivateShotCamera();

        if (IsDrivingLayup || IsDunking) Stamina?.DrainDrive();

        ShowFeedback(IsDunking ? "DUNK!" : IsDrivingLayup ? "LAYUP!" : "SHOOT!", NormalColor);
    }

    // Jump Tick
    private Vector3 _ballReleasePos;

    private void TickJump()
    {
        if (_jumpPhase == JumpPhase.None) return;

        _jumpPhaseTimer += Time.deltaTime;

        if (IsCharging)
        {
            _chargeTimer += Time.deltaTime;
            if (MeterFill != null)
            {
                float fill = Mathf.Clamp01(_chargeTimer / _currentPerfectWindow);
                MeterFill.fillAmount = fill;

                bool inGreenZone = fill >= 0.88f;
                MeterFill.color = inGreenZone ? PerfectColor :
                                  IsDunking      ? DunkBaseColor :
                                  IsDrivingLayup ? LayupBaseColor : NormalColor;
            }
        }

        float h = IsDunking      ? DunkJumpHeight :
                  IsDrivingLayup ? LayupJumpHeight :
                  JumpHeight;

        float yOffset = 0f;

        switch (_jumpPhase)
        {
            case JumpPhase.Rising:
                float riseT = Mathf.Clamp01(_jumpPhaseTimer / JumpRiseTime);
                yOffset = Mathf.Lerp(0f, h, EaseOut(riseT));
                if (_jumpPhaseTimer >= JumpRiseTime)
                {
                    _jumpPhase      = JumpPhase.Hanging;
                    _jumpPhaseTimer = 0f;
                }
                break;

            case JumpPhase.Hanging:
                float hangT = Mathf.Clamp01(_jumpPhaseTimer / JumpHangTime);
                yOffset = Mathf.Lerp(h, h * 0.88f, hangT);
                break;

            case JumpPhase.Falling:
                float fallT = Mathf.Clamp01(_jumpPhaseTimer / JumpFallTime);
                float peakH = h * 0.88f;
                yOffset = Mathf.Lerp(peakH, 0f, EaseIn(fallT));

                if (fallT >= 1f)
                {
                    _jumpPhase = JumpPhase.None;
                    if (_cc != null) _cc.enabled = true;
                    return;
                }
                break;
        }

        Vector3 targetPos = new Vector3(_initialPos.x, _jumpStartY + yOffset, _initialPos.z);

        if ((IsDrivingLayup || IsDunking) && IsCharging)
        {
            float totalTime  = JumpRiseTime + JumpHangTime;
            float progress   = Mathf.Clamp01(_chargeTimer / totalTime);
            Vector3 driveDir = (HoopTarget.position - _initialPos).normalized;
            driveDir.y       = 0f;
            float leap       = IsDunking ? 2.5f : LayupForwardLeap;
            targetPos       += driveDir * (progress * leap);
        }

        transform.position = targetPos;
    }

    // Release Shot
    private void StartFalling()
    {
        _jumpPhase      = JumpPhase.Falling;
        _jumpPhaseTimer = 0f;
    }

    private float EaseOut(float t) => 1f - (1f - t) * (1f - t);
    private float EaseIn(float t)  => t * t;

    private void ReleaseShot()
    {
        IsCharging = false;
        if (MeterRoot != null) MeterRoot.SetActive(false);
        if (GreenZoneMarker != null) GreenZoneMarker.gameObject.SetActive(false);

        Transform handSlot = BallHandler.IsRightHanded
            ? BallHandler.RightHandSlot
            : BallHandler.LeftHandSlot;

        _ballReleasePos = (handSlot != null ? handSlot.position : transform.position + Vector3.up * 1.5f)
                        + Vector3.up * BallReleaseHeight;

        StartFalling();

        BallState bs = BallHandler.Ball.GetComponent<BallState>();
        if (bs != null) bs.SetShotData(transform.position, gameObject);

        float shotDist = Vector3.Distance(
            new Vector3(transform.position.x, 0f, transform.position.z),
            new Vector3(HoopTarget.position.x, 0f, HoopTarget.position.z));
        bool isThreePt = shotDist > ThreePointRadius;

        _currentContestLevel = CalculateContest();
        bool isBlocked = _currentContestLevel > 0.4f &&
                         Random.value < (_currentContestLevel * BaseBlockChance);

        float timingDiff = Mathf.Abs(_chargeTimer - _currentPerfectWindow);
        bool  isPerfect  = timingDiff < 0.07f;
        bool  isGood     = timingDiff < (_currentPerfectWindow * 0.35f);

        if (TimingLabel != null)
        {
            if (isPerfect)      { TimingLabel.text = "PERFECT";    TimingLabel.color = PerfectColor; }
            else if (isGood)    { TimingLabel.text = "GOOD";       TimingLabel.color = GoodColor;    }
            else                { TimingLabel.text = _chargeTimer < _currentPerfectWindow ? "EARLY" : "LATE";
                                  TimingLabel.color = BadColor; }
            StartCoroutine(FadeTimingLabel());
        }
        if (TimingFlash != null) StartCoroutine(FlashTimingImage(isPerfect ? PerfectColor : isGood ? GoodColor : BadColor));

        if (IsDunking)
        {
            bool ok = !isBlocked && timingDiff < DunkPerfectWindow * 0.8f;
            ShowFeedback(isBlocked ? "BLOCKED!" : ok ? "SLAM DUNK!" : "MISSED DUNK",
                         ok ? PerfectColor : BadColor);
            StartCoroutine(DunkSequence(ok));
        }
        else if (IsDrivingLayup)
        {
            Rigidbody ballRb = BallHandler.Ball.GetComponent<Rigidbody>();
            ballRb.isKinematic = true;
            BallHandler.Ball.transform.position = _ballReleasePos;

            BallHandler.ReleaseBallForShot();
            bool ok = !isBlocked && timingDiff < LayupPerfectWindow * 0.75f;
            if (isBlocked) { ApplyBlockPhysics(); ShowFeedback("BLOCKED!", BadColor); DeactivateShotCamera(); }
            else if (ok)   { ShowFeedback(isPerfect ? "PERFECT LAYUP!" : "GOOD LAYUP", PerfectColor);
                             _targetFOV = PullbackFOV;
                             StartCoroutine(LayupArc(BallHandler.Ball, isPerfect)); }
            else           { ShowFeedback("MISSED LAYUP", BadColor);
                             LaunchBall(false, false, false); }
        }
        else
        {
            Rigidbody ballRb = BallHandler.Ball.GetComponent<Rigidbody>();
            ballRb.isKinematic = true;
            BallHandler.Ball.transform.position = _ballReleasePos;
            BallHandler.ReleaseBallForShot();

            SetTrail(isBlocked ? BadColor : isPerfect ? PerfectColor : NormalColor);
            _lastShotWasPerfect = isPerfect;

            if (isBlocked)
            {
                ApplyBlockPhysics();
                ShowFeedback("BLOCKED!", BadColor);
                DeactivateShotCamera();
            }
            else if (isPerfect && _lastShotWasMidrange)
            {
                ShowFeedback("PERFECT!", PerfectColor);
                _targetFOV = MidrangeZoomFOV;
                StartCoroutine(MidrangeArc(BallHandler.Ball));
            }
            else if (isPerfect)
            {
                ShowFeedback("3PT PERFECT", PerfectColor);
                _targetFOV = PullbackFOV;
                LaunchBall(true, false, true);
            }
            else
            {
                string label = isGood ? (isThreePt ? "3PT - GOOD" : "GOOD SHOT")
                                      : (isThreePt ? "3PT - EARLY/LATE" : "EARLY / LATE");
                ShowFeedback(label, isGood ? GoodColor : BadColor);
                _targetFOV = PullbackFOV;
                LaunchBall(false, isGood, isThreePt);
            }
        }

        IsDunking      = false;
        IsDrivingLayup = false;
        StartCoroutine(DisableTrail(1.8f));
    }

    // Shot System

    [Header("Shot Physics")]
    public float LaunchAngle        = 48f;
    public float MinLaunchSpeed     = 8f;
    public float MagnetStrength     = 45f;
    public float MagnetRange        = 4.5f;
    public float LayupArcDuration   = 0.75f;

    private float ArcEase(float t) => t * t * (3f - 2f * t);

    private void LaunchBall(bool isPerfect, bool isGood, bool isThreePt)
    {
        Rigidbody rb      = BallHandler.Ball.GetComponent<Rigidbody>();
        rb.isKinematic    = false;
        rb.useGravity     = true;

        Vector3 origin    = _ballReleasePos;
        Vector3 target    = HoopTarget.position;
        Vector3 velocity  = CalculateLaunchVelocity(origin, target, LaunchAngle);

        if (velocity.magnitude < MinLaunchSpeed)
            velocity = velocity.normalized * MinLaunchSpeed;

        if (!isPerfect && !isGood)
        {
            float errorSign = _chargeTimer < _currentPerfectWindow ? -1f : 1f;
            velocity += transform.forward * errorSign * Random.Range(1.5f, 3f);
            velocity += Random.insideUnitSphere * 1.2f;
        }
        else if (!isPerfect)
        {
            velocity += Random.insideUnitSphere * 0.6f;
        }

        rb.linearVelocity = velocity;
        rb.AddTorque(transform.right * 8f, ForceMode.Impulse);

        if (isPerfect) StartCoroutine(MagnetToHoop(rb, isThreePt));
        else           StartCoroutine(WaitThenReturnCamera());
    }

    private Vector3 CalculateLaunchVelocity(Vector3 origin, Vector3 target, float angleDeg)
    {
        float angle = angleDeg * Mathf.Deg2Rad;
        float g     = Mathf.Abs(Physics.gravity.y);

        Vector3 dir2D = target - origin;
        float   yDiff = dir2D.y;
        dir2D.y       = 0f;
        float   dist  = dir2D.magnitude;

        if (dist < 0.01f)
            return Vector3.up * Mathf.Sqrt(2f * g * (target.y - origin.y + 1f));

        float tanA   = Mathf.Tan(angle);
        float cosA   = Mathf.Cos(angle);
        float denom  = dist * tanA - yDiff;

        if (denom <= 0f)
        {
            angle  = 60f * Mathf.Deg2Rad;
            tanA   = Mathf.Tan(angle);
            cosA   = Mathf.Cos(angle);
            denom  = dist * tanA - yDiff;
        }

        float v2 = (g * dist * dist) / (2f * cosA * cosA * Mathf.Max(denom, 0.01f));
        float v  = Mathf.Sqrt(Mathf.Max(v2, MinLaunchSpeed * MinLaunchSpeed));

        return dir2D.normalized * v * cosA + Vector3.up * v * Mathf.Sin(angle);
    }

    private IEnumerator MagnetToHoop(Rigidbody rb, bool isThreePt)
    {
        if (rb == null) yield break;

        float timeout = 5f;
        float elapsed = 0f;
        bool  locked  = false;

        while (elapsed < timeout && rb != null)
        {
            if (BallHandler.HasBall) yield break;

            elapsed += Time.deltaTime;

            Vector3 toHoop = HoopTarget.position - rb.transform.position;
            float   dist   = toHoop.magnitude;

            if (dist < MagnetRange)
            {
                locked = true;

                rb.transform.position = new Vector3(
                    Mathf.Lerp(rb.transform.position.x, HoopTarget.position.x, 0.35f),
                    rb.transform.position.y,
                    Mathf.Lerp(rb.transform.position.z, HoopTarget.position.z, 0.35f));

                Vector3 v = rb.linearVelocity;
                rb.linearVelocity = new Vector3(
                    Mathf.Lerp(v.x, 0f, 0.3f),
                    v.y,
                    Mathf.Lerp(v.z, 0f, 0.3f));

                float xzDist = Vector2.Distance(
                    new Vector2(rb.transform.position.x, rb.transform.position.z),
                    new Vector2(HoopTarget.position.x,   HoopTarget.position.z));

                if (xzDist < 0.12f && rb.linearVelocity.y < 0f)
                {
                    rb.transform.position = new Vector3(
                        HoopTarget.position.x,
                        rb.transform.position.y,
                        HoopTarget.position.z);
                    rb.linearVelocity = Vector3.down * 7f;
                    break;
                }
            }

            if (locked && rb.transform.position.y < HoopTarget.position.y - 0.2f)
                break;

            yield return null;
        }

        if (!BallHandler.HasBall && rb != null
            && rb.transform.position.y > HoopTarget.position.y - 0.5f)
        {
            rb.transform.position = HoopTarget.position;
            rb.linearVelocity     = Vector3.down * 6f;
        }

        yield return new WaitForSeconds(ShotCamReturnDelay);
        _targetFOV = NormalFOV;
        DeactivateShotCamera();
    }

    private IEnumerator WaitThenReturnCamera()
    {
        yield return new WaitForSeconds(2.5f);
        _targetFOV = NormalFOV;
        DeactivateShotCamera();
    }

    private IEnumerator LayupArc(GameObject ball, bool perfect)
    {
        Rigidbody rb   = ball.GetComponent<Rigidbody>();
        rb.isKinematic = true;

        Vector3 start = _ballReleasePos;
        ball.transform.position = start;

        Vector3 end  = HoopTarget.position;
        float   peakY = Mathf.Max(start.y, end.y) + 1.4f;
        Vector3 mid  = new Vector3(
            Mathf.Lerp(start.x, end.x, 0.55f),
            peakY,
            Mathf.Lerp(start.z, end.z, 0.55f));

        float elapsed = 0f;
        while (elapsed < LayupArcDuration)
        {
            elapsed += Time.deltaTime;
            float t  = ArcEase(Mathf.Clamp01(elapsed / LayupArcDuration));
            ball.transform.position = Vector3.Lerp(
                Vector3.Lerp(start, mid, t),
                Vector3.Lerp(mid,   end, t), t);
            yield return null;
        }

        ball.transform.position = end;
        rb.isKinematic    = false;
        rb.linearVelocity = Vector3.down * (perfect ? 4f : 6f);

        yield return new WaitForSeconds(ShotCamReturnDelay);
        DeactivateShotCamera();
    }

    private IEnumerator MidrangeArc(GameObject ball)
    {
        Rigidbody rb   = ball.GetComponent<Rigidbody>();
        rb.isKinematic = true;

        Vector3 start = _ballReleasePos;
        ball.transform.position = start;

        Vector3 hoopAbove = HoopTarget.position + Vector3.up * 0.08f;
        float   peakY = Mathf.Max(start.y, HoopTarget.position.y) + 2.8f;
        Vector3 mid   = new Vector3(
            Mathf.Lerp(start.x, HoopTarget.position.x, 0.5f),
            peakY,
            Mathf.Lerp(start.z, HoopTarget.position.z, 0.5f));

        float riseTime = MidrangeArcDuration * 0.55f;
        float elapsed  = 0f;
        while (elapsed < riseTime)
        {
            if (BallHandler.HasBall) { rb.isKinematic = false; yield break; }
            elapsed += Time.deltaTime;
            float t  = 1f - Mathf.Pow(1f - Mathf.Clamp01(elapsed / riseTime), 2f);
            ball.transform.position = Vector3.Lerp(
                Vector3.Lerp(start, mid, t),
                Vector3.Lerp(mid, hoopAbove, t), t);
            yield return null;
        }

        float dropTime = MidrangeArcDuration * 0.45f;
        elapsed = 0f;
        Vector3 dropStart = ball.transform.position;
        while (elapsed < dropTime)
        {
            if (BallHandler.HasBall) { rb.isKinematic = false; yield break; }
            elapsed += Time.deltaTime;
            float t  = Mathf.Pow(Mathf.Clamp01(elapsed / dropTime), 2f);
            ball.transform.position = Vector3.Lerp(dropStart, hoopAbove, t);
            yield return null;
        }

        ball.transform.position = HoopTarget.position;
        rb.isKinematic    = false;
        rb.linearVelocity = Vector3.down * 6f;

        yield return new WaitForSeconds(0.3f);
        _targetFOV = PullbackFOV;

        yield return new WaitForSeconds(ShotCamReturnDelay);
        _targetFOV = NormalFOV;
        DeactivateShotCamera();
    }

    private IEnumerator DunkSequence(bool success)
    {
        BallHandler.ReleaseBallForShot();
        Rigidbody rb   = BallHandler.Ball.GetComponent<Rigidbody>();
        rb.isKinematic = true;

        Vector3 start = BallHandler.Ball.transform.position;
        Vector3 end   = DunkSlamPoint != null
            ? DunkSlamPoint.position
            : HoopTarget.position + Vector3.up * 0.5f;

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime * DunkSpeed;
            BallHandler.Ball.transform.position = Vector3.Lerp(start, end, t);
            yield return null;
        }

        rb.isKinematic = false;
        if (success)
        {
            rb.linearVelocity = Vector3.down * 18f;
            // Dunk scores go through the networked server RPC - the server
            // validates possession/distance and updates the replicated score.
            // The HoopSensor would catch this too, but dunks bypass the
            // physics check so we report directly.
            if (BasketballGameManager.Instance != null)
                BasketballGameManager.Instance.ReportScoreServerRpc(2, transform.position);
        }
        else
        {
            rb.linearVelocity = Vector3.up * 5f + transform.forward * -3f;
        }

        yield return new WaitForSeconds(ShotCamReturnDelay);
        DeactivateShotCamera();
    }

    // Cinematic Shot Camera
    private void ActivateShotCamera()
    {
        if (ShotVCam == null || !gameObject.CompareTag("Player")) return;
        ShotVCam.Priority = ShotCamPriority;
        _inShotCam        = true;
    }

    private void DeactivateShotCamera()
    {
        if (ShotVCam == null) return;
        ShotVCam.Priority = 0;
        _inShotCam        = false;
        _targetFOV        = NormalFOV;
    }

    private void TickShotCamera()
    {
        if (!_inShotCam || ShotCamRig == null || HoopTarget == null) return;
        if (!gameObject.CompareTag("Player")) return;

        Vector3 toHoop    = HoopTarget.position - transform.position;
        toHoop.y          = 0f;
        Vector3 toHoopDir = toHoop.magnitude > 0.1f ? toHoop.normalized : transform.forward;
        Vector3 behindDir = -toHoopDir;
        Vector3 sideDir   = Vector3.Cross(Vector3.up, toHoopDir).normalized;

        Vector3 targetPos;
        Vector3 lookAt;

        if (IsCharging)
        {
            if (_lastShotWasMidrange)
            {
                targetPos = transform.position
                          + sideDir    * 2.2f
                          + behindDir  * 2.8f
                          + Vector3.up * 1.6f;
                lookAt    = transform.position + Vector3.up * 2.2f;
            }
            else
            {
                targetPos = transform.position
                          + behindDir  * ShotCamBehindDist
                          + Vector3.up * ShotCamHeight;
                lookAt    = transform.position + Vector3.up * 1.5f;
            }
        }
        else
        {
            if (_lastShotWasMidrange && _lastShotWasPerfect)
            {
                Vector3 behindHoop = HoopTarget.position
                                   - toHoopDir * 3.5f
                                   + sideDir   * 5f
                                   + Vector3.up * 2.5f;
                targetPos = behindHoop;
                lookAt    = HoopTarget.position + Vector3.up * 0.3f;
            }
            else if (_lastShotWasMidrange)
            {
                targetPos = transform.position
                          + sideDir    * 4f
                          + behindDir  * 4f
                          + Vector3.up * 3f;
                lookAt    = HoopTarget.position;
            }
            else
            {
                Vector3 midpoint = (transform.position + HoopTarget.position) * 0.5f;
                targetPos = midpoint
                          + behindDir  * ShotCamPullbackDist
                          + Vector3.up * ShotCamPullbackHeight;
                lookAt    = midpoint + Vector3.up * 1f;
            }
        }

        float smooth = _lastShotWasMidrange ? ShotCamSmooth * 0.6f : ShotCamSmooth;

        ShotCamRig.position = Vector3.SmoothDamp(
            ShotCamRig.position, targetPos,
            ref _shotCamVelocity, smooth);

        ShotCamRig.rotation = Quaternion.Slerp(
            ShotCamRig.rotation,
            Quaternion.LookRotation((lookAt - ShotCamRig.position).normalized),
            10f * Time.deltaTime);
    }

    private void TickMainCameraFOV()
    {
        if (VCam != null && gameObject.CompareTag("Player"))
            VCam.Lens.FieldOfView = Mathf.Lerp(
                VCam.Lens.FieldOfView, _targetFOV, ZoomSpeed * Time.deltaTime);
    }

    // Defense
    private void TryBlock()
    {
        if (_blockTimer > 0 || OpponentTransform == null) return;

        float dist = Vector3.Distance(transform.position, OpponentTransform.position);
        if (dist > MaxContestDist * 0.6f) { ShowFeedback("Out of range", BadColor); return; }

        _blockTimer   = BlockCooldown;
        IsInBlockPose = true;

        PlayerShooting opp = OpponentTransform.GetComponent<PlayerShooting>();
        bool success = opp != null && opp.IsCharging && Random.value < BaseBlockChance;
        ShowFeedback(success ? "BLOCK!" : "Missed block",
                     success ? PerfectColor : BadColor);

        StartCoroutine(ClearBlockPose());
    }

    private IEnumerator ClearBlockPose()
    {
        yield return new WaitForSeconds(0.4f);
        IsInBlockPose = false;
    }

    private float CalculateContest()
    {
        if (OpponentTransform == null) return 0f;
        PlayerShooting opp = OpponentTransform.GetComponent<PlayerShooting>();
        if (opp == null || (!opp.IsDefending && !opp.IsInBlockPose)) return 0f;
        float d = Vector3.Distance(transform.position, OpponentTransform.position);
        return d > MaxContestDist ? 0f : Mathf.Clamp01(1f - d / MaxContestDist);
    }

    private void ApplyBlockPhysics()
    {
        Rigidbody rb = BallHandler.Ball.GetComponent<Rigidbody>();
        Vector3 dir  = (transform.position - HoopTarget.position).normalized;
        dir.y        = 0.6f;
        rb.linearVelocity = dir * 9f;
    }

    // Helpers
    private void SetTrail(Color col)
    {
        if (_ballTrail == null) return;
        _ballTrail.emitting    = true;
        _ballTrail.startColor  = col;
    }

    private IEnumerator DisableTrail(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (_ballTrail != null && !IsCharging) _ballTrail.emitting = false;
    }

    private Coroutine _feedbackRoutine;
    private void ShowFeedback(string msg, Color col)
    {
        if (FeedbackText == null) return;
        FeedbackText.text  = msg;
        FeedbackText.color = col;
        if (_feedbackRoutine != null) StopCoroutine(_feedbackRoutine);
        _feedbackRoutine = StartCoroutine(ClearFeedback());
    }
    private IEnumerator ClearFeedback()
    {
        yield return new WaitForSeconds(2f);
        if (FeedbackText != null) FeedbackText.text = "";
    }

    private IEnumerator FadeTimingLabel()
    {
        if (TimingLabel == null) yield break;
        yield return new WaitForSeconds(0.6f);
        float t = 0f;
        Color start = TimingLabel.color;
        while (t < 1f)
        {
            t += Time.deltaTime / 0.4f;
            TimingLabel.color = new Color(start.r, start.g, start.b, Mathf.Lerp(1f, 0f, t));
            yield return null;
        }
        TimingLabel.text = "";
    }

    private IEnumerator FlashTimingImage(Color col)
    {
        if (TimingFlash == null) yield break;
        TimingFlash.color = new Color(col.r, col.g, col.b, 0.85f);
        yield return new WaitForSeconds(0.1f);
        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / 0.35f;
            TimingFlash.color = new Color(col.r, col.g, col.b, Mathf.Lerp(0.85f, 0f, t));
            yield return null;
        }
    }

    public void ResetShootingState()
    {
        IsCharging = IsDrivingLayup = IsDunking = false;
        _jumpPhase  = JumpPhase.None;
        _targetFOV  = NormalFOV;
        _lastShotWasMidrange = false;
        _lastShotWasPerfect  = false;
        _prevShootHeld = false;
        _prevLayupHeld = false;
        StopAllCoroutines();
        if (_cc        != null) _cc.enabled = true;
        if (MeterRoot  != null) MeterRoot.SetActive(false);
        if (GreenZoneMarker != null) GreenZoneMarker.gameObject.SetActive(false);
        if (_ballTrail != null) _ballTrail.emitting = false;
        IsInBlockPose = false;
        DeactivateShotCamera();
    }
}
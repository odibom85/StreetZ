using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;
using Unity.Netcode;

/// <summary>
/// Player defensive actions: defensive stance (slows movement, drains stamina) and
/// active steal attempts on the opponent's ball.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerDefense : MonoBehaviour
{
    // References
    [Header("References")]
    public PlayerShooting    ShootingScript;
    public Transform         OpponentTransform;
    public PlayerBallHandler OpponentBall;

    // Steal
    [Header("Steal Settings")]
    public float StealReach    = 1.8f;
    public float StealCooldown = 2.0f;
    [Range(0,100)]
    public float StealChance   = 30f;
    [Tooltip("Bonus steal % when opponent is mid-dribble-move")]
    public float StealMoveBonus = 20f;

    // Defensive Stance
    [Header("Defensive Stance")]
    public float StanceSpeedMult     = 0.6f;
    public float BaseMovementSpeed   = 5f;
    public float StaminaDrain        = 0.12f;
    public float StaminaRecover      = 0.08f;

    // Public State
    [HideInInspector] public bool  IsInDefensiveStance = false;
    [HideInInspector] public float DefenseStamina      = 1f;

    // UI
    [Header("UI")]
    public TextMeshProUGUI StealFeedbackText;
    public TextMeshProUGUI StaminaBarText;

    // Private
    private CharacterController _cc;
    private PlayerController    _controller;
    private PlayerBallHandler   _localBallHandler;
    private NetworkObject       _netObj;
    private float _stealCooldownTimer;

    // Unity
    void Awake()
    {
        _cc               = GetComponent<CharacterController>();
        _controller       = GetComponent<PlayerController>();
        _localBallHandler = GetComponent<PlayerBallHandler>();
        _netObj           = GetComponent<NetworkObject>();

        if (ShootingScript == null)
            ShootingScript = GetComponent<PlayerShooting>();
    }

    void Update()
    {
        // Only process input for local player
        if (_netObj != null && !_netObj.IsOwner) return;

        if (_stealCooldownTimer > 0) _stealCooldownTimer -= Time.deltaTime;

        PollStealInput();
        UpdateStanceSpeedEffect();
        UpdateStaminaUI();
    }

    // Direct Input Polling
    private void PollStealInput()
    {
        Gamepad  gp = Gamepad.current;
        Keyboard kb = Keyboard.current;

        // Steal - B / Circle or Q key
        bool stealPressed = (gp != null && gp.buttonEast.wasPressedThisFrame)
                         || (kb != null && kb.qKey.wasPressedThisFrame);

        // Only attempt steal when not holding ball
        if (stealPressed && _localBallHandler != null && !_localBallHandler.HasBall)
            TrySteal();
    }

    // Steal Logic
    private void TrySteal()
    {
        if (_stealCooldownTimer > 0)
        {
            ShowFeedback($"Cooldown {_stealCooldownTimer:0.0}s", Color.gray, 0.6f);
            return;
        }

        if (OpponentBall == null || !OpponentBall.HasBall)
        {
            ShowFeedback("No ball to steal", Color.gray, 0.6f);
            return;
        }

        float dist = Vector3.Distance(transform.position, OpponentBall.Ball.transform.position);
        if (dist > StealReach)
        {
            ShowFeedback("Too far!", Color.red, 0.8f);
            _stealCooldownTimer = 0.5f;
            return;
        }

        _stealCooldownTimer = StealCooldown;

        float moveBonus = 0f;
        if (OpponentBall != null)
        {
            float ballHandDist = Vector3.Distance(
                OpponentBall.Ball.transform.position,
                OpponentTransform.position);
            if (ballHandDist > 0.6f) moveBonus = StealMoveBonus;
        }

        float roll    = Random.Range(0f, 100f);
        float chance  = StealChance + moveBonus;

        CharacterController oppCC = OpponentTransform != null
            ? OpponentTransform.GetComponent<CharacterController>() : null;
        if (oppCC != null && oppCC.velocity.magnitude < 0.2f) chance += 15f;

        if (roll < chance)
            PerformSteal();
        else
            ShowFeedback("Missed steal!", Color.red, 0.8f);
    }

    private void PerformSteal()
    {
        OpponentBall.ReleaseBallForShot();

        Rigidbody rb    = OpponentBall.Ball.GetComponent<Rigidbody>();
        rb.isKinematic  = false;
        rb.useGravity   = true;

        Vector3 pokeDir = (transform.forward + Random.insideUnitSphere * 0.25f).normalized;
        rb.AddForce(pokeDir * 5f, ForceMode.Impulse);

        ShowFeedback("STEAL!", Color.green, 1.5f);
        Debug.Log("Player Steal Success!");
    }

    // Defensive Stance Tick
    private void UpdateStanceSpeedEffect()
    {
        if (_controller == null) return;

        // Defensive stance input - only when not holding ball
        // Note: PlayerStamina also reads this input and pushes IsInDefensiveStance.
        // If PlayerStamina is present, it is the authority - this is a fallback.
        bool stanceHeld = false;
        if (_localBallHandler == null || !_localBallHandler.HasBall)
        {
            stanceHeld = (Gamepad.current  != null && Gamepad.current.leftShoulder.isPressed)
                      || (Keyboard.current != null && Keyboard.current.leftCtrlKey.isPressed);
        }

        // Only self - drive stance if PlayerStamina isn't doing it
        PlayerStamina stam = GetComponent<PlayerStamina>();
        if (stam == null)
        {
            IsInDefensiveStance = stanceHeld && DefenseStamina > 0f;

            if (IsInDefensiveStance)
                DefenseStamina = Mathf.Max(0f, DefenseStamina - StaminaDrain * Time.deltaTime);
            else
                DefenseStamina = Mathf.Min(1f, DefenseStamina + StaminaRecover * Time.deltaTime);
        }

        if (ShootingScript != null)
            ShootingScript.IsDefending = IsInDefensiveStance;

        float targetSpeed = IsInDefensiveStance ? BaseMovementSpeed * StanceSpeedMult : BaseMovementSpeed;
        _controller.MoveSpeed = Mathf.Lerp(_controller.MoveSpeed, targetSpeed, Time.deltaTime * 8f);
    }

    // UI
    private void UpdateStaminaUI()
    {
        if (StaminaBarText == null) return;

        string bar   = "[";
        int    filled = Mathf.RoundToInt(DefenseStamina * 10f);
        for (int i = 0; i < 10; i++) bar += (i < filled) ? "■" : "□";
        bar += "]";

        StaminaBarText.text = IsInDefensiveStance
            ? $"DEF {bar}"
            : (DefenseStamina < 1f ? $"Recovering {bar}" : "");
    }

    private void ShowFeedback(string msg, Color col, float duration)
    {
        if (StealFeedbackText == null) return;
        StealFeedbackText.text  = msg;
        StealFeedbackText.color = col;
        CancelInvoke(nameof(ClearFeedback));
        Invoke(nameof(ClearFeedback), duration);
    }

    private void ClearFeedback()
    {
        if (StealFeedbackText != null) StealFeedbackText.text = "";
    }

    // Gizmo
#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, StealReach);
    }
#endif
}
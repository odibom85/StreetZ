using UnityEngine;
using UnityEngine.AI;
using System.Collections;

public class AIController : MonoBehaviour
{
    public enum AIState { Idle, Offense, Defense }
    public AIState CurrentState = AIState.Idle;

    public Transform HoopTarget;
    public Transform PlayerTarget;
    
    private NavMeshAgent _agent;
    private PlayerBallHandler _ballHandler;
    private PlayerShooting _shooting;

    void Awake()
    {
        _agent = GetComponent<NavMeshAgent>();
        _ballHandler = GetComponent<PlayerBallHandler>();
        _shooting = GetComponent<PlayerShooting>();
    }

    void Update()
    {
        if (BasketballGameManager.Instance == null) return;
        if (!BasketballGameManager.Instance.BallInPlay) return;

        if (_ballHandler != null && _ballHandler.HasBall)
            CurrentState = AIState.Offense;
        else
            CurrentState = AIState.Defense;

        if (CurrentState == AIState.Offense) HandleOffense();
        else HandleDefense();
    }

    private void HandleOffense()
    {
        if (HoopTarget != null) _agent.SetDestination(HoopTarget.position);
    }

    private void HandleDefense()
    {
        if (PlayerTarget != null)
        {
            Vector3 guardPos = Vector3.Lerp(PlayerTarget.position, HoopTarget.position, 0.5f);
            _agent.SetDestination(guardPos);
        }
    }
}
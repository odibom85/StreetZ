using UnityEngine;
using Unity.Cinemachine;

/// <summary>
/// Attach this to a GameObject alongside a CinemachineCamera component.
/// It dynamically positions the camera so both the Player and the Hoop
/// stay comfortably in frame at all times.
/// </summary>
[RequireComponent(typeof(CinemachineCamera))]
public class RimFocusedCamera : MonoBehaviour
{
    [Header("Targets")]
    public Transform Player;
    public Transform Hoop;

    [Header("Framing")]
    [Tooltip("Extra world-space padding added around the two targets")]
    public float FramePadding = 3.5f;

    [Tooltip("Minimum distance the camera will ever be from the midpoint")]
    public float MinDistance = 5f;

    [Tooltip("Maximum distance the camera will ever be from the midpoint")]
    public float MaxDistance = 18f;

    [Header("Camera Angle")]
    [Tooltip("How high above the midpoint the camera sits (world units)")]
    public float HeightOffset = 4f;

    [Tooltip("How far behind the player (away from hoop) the camera pulls back")]
    public float BehindPlayerOffset = 2f;

    [Header("Smoothing")]
    [Tooltip("How quickly the camera catches up to its target position")]
    public float PositionSmoothTime = 0.18f;

    [Tooltip("How quickly the camera rotates to look at the focus point")]
    public float RotationSmoothSpeed = 6f;

    [Header("Look-At Focus")]
    [Tooltip("0 = look at Player, 1 = look at Hoop, 0.5 = midpoint between them")]
    [Range(0f, 1f)]
    public float LookAtBias = 0.55f;

    [Tooltip("Extra upward offset on the look-at point so the hoop rim stays centred")]
    public float LookAtHeightBias = 0.8f;

    // Private
    private CinemachineCamera _vCam;
    private Vector3 _posVelocity;

    // Unity
    void Awake()
    {
        _vCam = GetComponent<CinemachineCamera>();
    }

    void LateUpdate()
    {
        if (Player == null || Hoop == null) return;

        // 1. Work out the ideal camera position
        // Midpoint between player and hoop (flat, on the ground plane)
        Vector3 midPoint = (Player.position + Hoop.position) * 0.5f;

        // Direction from hoop → player (the "behind-player" axis)
        Vector3 behindDir = (Player.position - Hoop.position);
        behindDir.y = 0f;
        float separation = behindDir.magnitude;          // how far apart they are
        behindDir = separation > 0.01f
            ? behindDir.normalized
            : Vector3.forward;

        // Distance needed to keep both in frame with padding
        float requiredDist = Mathf.Clamp(
            (separation * 0.5f) + FramePadding,
            MinDistance,
            MaxDistance
        );

        Vector3 targetPos = midPoint
            + behindDir  * (BehindPlayerOffset)   // pull back behind player
            + Vector3.up * HeightOffset;           // lift up

        // Scale back along behindDir so the two subjects fit
        targetPos = midPoint
            + behindDir  * requiredDist
            + Vector3.up * HeightOffset;

        // 2. Smooth position
        Vector3 smoothedPos = Vector3.SmoothDamp(
            transform.position,
            targetPos,
            ref _posVelocity,
            PositionSmoothTime
        );
        transform.position = smoothedPos;

        // 3. Smooth look-at rotation
        // Blend between player and hoop so neither drifts to the edge
        Vector3 focusPoint = Vector3.Lerp(
            Player.position,
            Hoop.position + Vector3.up * LookAtHeightBias,
            LookAtBias
        );

        Quaternion targetRot = Quaternion.LookRotation(
            (focusPoint - transform.position).normalized
        );
        transform.rotation = Quaternion.Slerp(
            transform.rotation,
            targetRot,
            RotationSmoothSpeed * Time.deltaTime
        );

        // 4. Push our transform into Cinemachine
        // Because Body/Aim are set to "Do Nothing", Cinemachine uses whatever
        // transform we set above - no extra configuration needed.
    }

#if UNITY_EDITOR
    // Draw a helpful gizmo in the Scene view
    void OnDrawGizmosSelected()
    {
        if (Player == null || Hoop == null) return;
        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(transform.position, Player.position);
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, Hoop.position);
        Gizmos.color = Color.yellow;
        Vector3 focus = Vector3.Lerp(Player.position,
            Hoop.position + Vector3.up * LookAtHeightBias, LookAtBias);
        Gizmos.DrawSphere(focus, 0.15f);
    }
#endif
}
using Unity.Netcode;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Lets the host kick the opponent client out of the match with a reason string.
/// Hidden automatically when there is no opponent or when the local client is not the host.
/// </summary>
public class KickOpponentButton : MonoBehaviour
{
    // UI
    [Header("UI")]
    [Tooltip("Button that triggers the kick. Hidden automatically for clients.")]
    public Button KickButton;

    // Settings
    [Header("Settings")]
    [Tooltip("Message sent to the kicked client before their socket closes")]
    public string KickReason = "Kicked by host";

    [Tooltip("Interval (seconds) between visibility checks")]
    public float VisibilityUpdateInterval = 0.5f;

    // Private
    private float _nextCheck;

    // Unity
    void Start()
    {
        if (KickButton != null)
        {
            KickButton.onClick.AddListener(OnKickClicked);
            KickButton.gameObject.SetActive(false); // hidden by default
        }
    }

    void Update()
    {
        // Cheap periodic visibility refresh. We don't subscribe to
        // connect/disconnect callbacks here because the visibility rule
        // is simple: "show the button if I'm host and an opponent exists".
        if (Time.unscaledTime < _nextCheck) return;
        _nextCheck = Time.unscaledTime + VisibilityUpdateInterval;

        if (KickButton == null) return;

        var nm = NetworkManager.Singleton;
        bool show =
            nm != null
            && nm.IsListening
            && nm.IsServer
            && HasOpponentConnected(nm);

        if (KickButton.gameObject.activeSelf != show)
            KickButton.gameObject.SetActive(show);
    }

    void OnDestroy()
    {
        if (KickButton != null)
            KickButton.onClick.RemoveListener(OnKickClicked);
    }

    // Logic
    private bool HasOpponentConnected(NetworkManager nm)
    {
        foreach (ulong id in nm.ConnectedClientsIds)
            if (id != NetworkManager.ServerClientId) return true;
        return false;
    }

    private void OnKickClicked()
    {
        var nm = NetworkManager.Singleton;
        if (nm == null || !nm.IsServer) return;

        // Find the first non-host client and disconnect them with a reason.
        // In a 1v1 game there's only ever one opponent so the first match
        // is the correct target.
        foreach (ulong id in nm.ConnectedClientsIds)
        {
            if (id == NetworkManager.ServerClientId) continue;

            Debug.Log($"[Kick] Disconnecting client {id}: {KickReason}");

            // NGO 2.x: DisconnectClient(clientId, reason) - the reason
            // string is delivered to the client and retrievable via
            // NetworkManager.DisconnectReason inside their own
            // OnClientDisconnectCallback handler.
            nm.DisconnectClient(id, KickReason);
            return;
        }
    }
}